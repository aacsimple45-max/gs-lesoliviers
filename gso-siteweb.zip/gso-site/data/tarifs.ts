export type LigneTarif = {
  cycle: string;
  inscription?: string;
  reinscription?: string;
  miTemps?: string;
  pleinTemps?: string;
  note?: string;
};

export type GrilleTarifs = {
  programme: string;
  monnaie: "FCFA";
  inscriptionGenerale?: string;
  reinscriptionGenerale?: string;
  lignes: LigneTarif[];
  notes: string[];
};

// Grilles tarifaires réelles, année scolaire 2026-2027 (source : prospectus GSO).
export const tarifsData: GrilleTarifs[] = [
  {
    programme: "Programme Français",
    monnaie: "FCFA",
    inscriptionGenerale: "15 000 Frs",
    reinscriptionGenerale: "7 500 Frs (au lieu de 10 000 Frs)",
    lignes: [
      { cycle: "Préscolaire (Crèche, TPS, PS, MS, GS)", miTemps: "25 000 Frs", pleinTemps: "28 000 Frs" },
      { cycle: "Primaire (CP à CM2)", miTemps: "25 000 Frs", pleinTemps: "28 000 Frs" },
    ],
    notes: [
      "Écolages payables sur 9 mois ; le mois de juin est déjà inséré dans chaque paiement.",
      "Horaires : du lundi au jeudi de 7h00 à 16h00, vendredi de 7h00 à 12h00.",
    ],
  },
  {
    programme: "Programme Congolais",
    monnaie: "FCFA",
    inscriptionGenerale: "5 000 Frs",
    reinscriptionGenerale: "3 000 Frs",
    lignes: [
      { cycle: "Maternelle", miTemps: "13 500 Frs", pleinTemps: "18 000 Frs" },
      { cycle: "Primaire", miTemps: "13 500 Frs", pleinTemps: "18 000 Frs" },
      { cycle: "Collège", miTemps: "17 000 Frs", pleinTemps: "22 000 Frs" },
      { cycle: "Lycée Général", miTemps: "19 500 Frs", pleinTemps: "—", note: "Un seul régime" },
      { cycle: "Classe de CM2 (examen)", miTemps: "17 000 Frs", pleinTemps: "—" },
      { cycle: "Classe de 3ème (examen)", miTemps: "22 500 Frs", pleinTemps: "—" },
      { cycle: "Classe de Terminale (examen)", miTemps: "26 000 Frs", pleinTemps: "—" },
    ],
    notes: [
      "Régimes au choix des parents : Mi-temps (7h–12h) ou Plein temps (7h–16h) pour Maternelle/Primaire/Collège.",
      "Réinscription gratuite pour tout élève ayant obtenu son CEPE ou son BEPC au GSO.",
      "Exonération de 10 % accordée aux familles nombreuses.",
    ],
  },
  {
    programme: "Lycée Technique",
    monnaie: "FCFA",
    inscriptionGenerale: "5 000 Frs",
    reinscriptionGenerale: "3 000 Frs",
    lignes: [
      { cycle: "Seconde", miTemps: "19 500 Frs / mois", pleinTemps: "—" },
      { cycle: "Première", miTemps: "19 500 Frs / mois", pleinTemps: "—" },
      { cycle: "Terminale", miTemps: "26 000 Frs / mois", pleinTemps: "—", note: "TD inclus" },
    ],
    notes: [
      "Deux vagues de cours de 6 heures : Seconde et Première 12h30–17h30, Terminale 7h15–12h15.",
      "Filières : Secrétariat (G1), Comptabilité (G2), Marketing & Gestion Financière (G3), Économie (BG).",
    ],
  },
];
