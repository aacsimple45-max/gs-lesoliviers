export type Fourniture = {
  classe: string;
  fichier: string;
  note?: string;
};

export type CycleFournitures = {
  cycle: string;
  items: Fourniture[];
};

export type ProgrammeFournitures = {
  programme: "congolais" | "francais";
  label: string;
  cycles: CycleFournitures[];
};

// Bibliothèque réelle des fournitures scolaires 2026-2027, Groupe Scolaire Les Oliviers.
// NB : la série "S" regroupe désormais les anciennes séries C et D (voir Première S / Terminale S).
export const fournituresData: ProgrammeFournitures[] = [
  {
    programme: "francais",
    label: "Programme Français",
    cycles: [
      {
        cycle: "Maternelle",
        items: [
          { classe: "TPS (2 ans)", fichier: "/docs/fournitures/francais/tps.pdf" },
          { classe: "PS (3 ans)", fichier: "/docs/fournitures/francais/ps.pdf" },
          { classe: "MS (4 ans)", fichier: "/docs/fournitures/francais/ms.pdf" },
          { classe: "GS (5 ans)", fichier: "/docs/fournitures/francais/gs.pdf" },
        ],
      },
      {
        cycle: "Primaire",
        items: [
          { classe: "CP (6 ans)", fichier: "/docs/fournitures/francais/cp.pdf" },
          { classe: "CE1", fichier: "/docs/fournitures/francais/ce1.pdf" },
          { classe: "CE2", fichier: "/docs/fournitures/francais/ce2.pdf" },
          { classe: "CM1", fichier: "/docs/fournitures/francais/cm1.pdf" },
          { classe: "CM2", fichier: "/docs/fournitures/francais/cm2.pdf" },
        ],
      },
    ],
  },
  {
    programme: "congolais",
    label: "Programme Congolais",
    cycles: [
      {
        cycle: "Maternelle",
        items: [
          { classe: "Crèche (9 mois – 2 ans)", fichier: "/docs/fournitures/congolais/creche.pdf" },
          { classe: "P1 — Petite Section (3 ans)", fichier: "/docs/fournitures/congolais/p1.pdf" },
          { classe: "P2 — Moyenne Section (4 ans)", fichier: "/docs/fournitures/congolais/p2.pdf" },
          { classe: "P3 — Grande Section (5 ans)", fichier: "/docs/fournitures/congolais/p3.pdf" },
        ],
      },
      {
        cycle: "Primaire",
        items: [
          { classe: "CP1", fichier: "/docs/fournitures/congolais/cp1.pdf" },
          { classe: "CP2", fichier: "/docs/fournitures/congolais/cp2.pdf" },
          { classe: "CE1", fichier: "/docs/fournitures/congolais/ce1.pdf" },
          { classe: "CE2", fichier: "/docs/fournitures/congolais/ce2.pdf" },
          { classe: "CM1", fichier: "/docs/fournitures/congolais/cm1.pdf" },
          { classe: "CM2", fichier: "/docs/fournitures/congolais/cm2.pdf" },
        ],
      },
      {
        cycle: "Collège",
        items: [
          { classe: "6e", fichier: "/docs/fournitures/congolais/6e.pdf" },
          { classe: "5e", fichier: "/docs/fournitures/congolais/5e.pdf" },
          { classe: "4e", fichier: "/docs/fournitures/congolais/4e.pdf" },
          { classe: "3e", fichier: "/docs/fournitures/congolais/3e.pdf" },
        ],
      },
      {
        cycle: "Lycée Général",
        items: [
          { classe: "Seconde (Tronc Commun)", fichier: "/docs/fournitures/congolais/seconde-tronc-commun.pdf" },
          { classe: "Première A (Littéraire)", fichier: "/docs/fournitures/congolais/premiere-a.pdf" },
          { classe: "Terminale A (Littéraire)", fichier: "/docs/fournitures/congolais/terminale-a.pdf" },
          {
            classe: "Première S — Série C/D",
            fichier: "/docs/fournitures/congolais/premiere-s.pdf",
            note: "La série S regroupe désormais les anciennes séries C et D.",
          },
          {
            classe: "Terminale S — Série C/D",
            fichier: "/docs/fournitures/congolais/terminale-s.pdf",
            note: "La série S regroupe désormais les anciennes séries C et D.",
          },
        ],
      },
      {
        cycle: "Lycée Technique",
        items: [
          {
            classe: "Seconde Commerciale (Tronc Commun)",
            fichier: "/docs/fournitures/congolais/seconde-commerciale-tronc-commun.pdf",
          },
          {
            classe: "Première G1 (Secrétariat)",
            fichier: "/docs/fournitures/congolais/premiere-g1.pdf",
            note: "Liste provisoire (identique à G2/G3/BG) — à remplacer par la liste propre au G1.",
          },
          {
            classe: "Première G2 / G3 / BG",
            fichier: "/docs/fournitures/congolais/premiere-g2-3-bg.pdf",
            note: "Comptabilité (G2), Marketing & Gestion Financière (G3), Économie (BG).",
          },
          {
            classe: "Première H (Informatique)",
            fichier: "/docs/fournitures/congolais/premiere-h.pdf",
            note: "Liste provisoire (identique à G2/G3/BG) — à remplacer par la liste propre au H.",
          },
          {
            classe: "Terminale G1 (Secrétariat)",
            fichier: "/docs/fournitures/congolais/terminale-g1.pdf",
            note: "Liste provisoire (identique à G2/G3/BG) — à remplacer par la liste propre au G1.",
          },
          {
            classe: "Terminale G2 / G3 / BG",
            fichier: "/docs/fournitures/congolais/terminale-g2-3-bg.pdf",
            note: "Comptabilité (G2), Marketing & Gestion Financière (G3), Économie (BG).",
          },
          {
            classe: "Terminale H (Informatique)",
            fichier: "/docs/fournitures/congolais/terminale-h.pdf",
            note: "Liste provisoire (identique à G2/G3/BG) — à remplacer par la liste propre au H.",
          },
        ],
      },
    ],
  },
];
