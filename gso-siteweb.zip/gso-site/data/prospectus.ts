export type Prospectus = {
  titre: string;
  description: string;
  fichier: string;
};

export const prospectusData: Prospectus[] = [
  {
    titre: "Prospectus — Programme Français",
    description:
      "Crèche, Maternelle (TPS/PS/MS/GS) et Primaire (CP à CM2) au programme français.",
    fichier: "/docs/prospectus/prospectus-programme-francais.pdf",
  },
  {
    titre: "Prospectus — Programme Congolais",
    description:
      "Maternelle, Primaire, Collège et Lycée Général au programme congolais.",
    fichier: "/docs/prospectus/prospectus-programme-congolais.pdf",
  },
  {
    titre: "Prospectus — Lycée Technique",
    description:
      "Filières commerciales : Secrétariat (G1), Comptabilité (G2), Marketing & Gestion Financière (G3), Économie (BG).",
    fichier: "/docs/prospectus/prospectus-lycee-technique.pdf",
  },
];
