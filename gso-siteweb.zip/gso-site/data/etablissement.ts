export const evenements = [
  "Fêtes de Noël (distribution des jouets)",
  "Célébration des anniversaires des élèves à l'école",
  "Organisation des émulations chaque fin de trimestre",
  "Organisation des olympiades, des jeux concours et activités extra-scolaires",
];

export const atoutsEtablissement = [
  "Suivi personnalisé de chaque élève",
  "Initiation à la langue anglaise dès la classe de CP",
  "Initiation des élèves à la technique bibliothécaire",
  "Soins de première nécessité avec une trousse permanente de santé",
  "Organisation régulière d'activités culturelles (théâtre, club de lecture, chorale) et sportives (football, handball)",
  "Initiation à l'outil informatique dès le CE1, avec accès Internet",
  "Organisation des devoirs hebdomadaires, évaluations mensuelles et compositions trimestrielles",
  "Exonération de 10 % accordée aux familles nombreuses",
  "Réinscription gratuite pour tout élève ayant obtenu son CEPE ou son BEPC chez nous",
];

export const pourquoiInscrire = [
  "Nos enseignants sont recrutés sur présentation de leurs titres académiques et professionnels ; ils sont encadrés par des inspecteurs expérimentés",
  "La direction est tenue par des spécialistes de l'éducation",
  "De petits tests de placement sont organisés lors du recrutement des élèves et des enseignants",
];

export const methodesEnseignement = [
  { titre: "Pédagogie active", texte: "L'élève est acteur de ses apprentissages, pas seulement récepteur." },
  { titre: "Apprentissage progressif", texte: "Une progression construite, du plus simple au plus complexe." },
  { titre: "Accompagnement individualisé", texte: "Un suivi personnalisé pour chaque élève, en particulier en difficulté." },
  { titre: "Évaluation régulière", texte: "Devoirs hebdomadaires, évaluations mensuelles, compositions trimestrielles." },
  { titre: "Suivi des progrès", texte: "Communication régulière avec les parents sur les résultats de l'enfant." },
  { titre: "Numérique adapté", texte: "Initiation à l'informatique dès le CE1, salle multimédia équipée." },
];
