-- =========================================================
-- Supabase Storage — buckets pour documents et images
-- À exécuter après schema.sql (Éditeur SQL, ou via l'onglet Storage).
-- =========================================================

insert into storage.buckets (id, name, public)
values
  ('documents', 'documents', true),   -- fournitures + prospectus (PDF)
  ('galerie', 'galerie', true),       -- photos de la galerie
  ('actualites', 'actualites', true)  -- images des actualités
on conflict (id) do nothing;

-- Lecture publique sur les 3 buckets (site vitrine)
create policy "lecture_publique_documents" on storage.objects
  for select using (bucket_id = 'documents');
create policy "lecture_publique_galerie" on storage.objects
  for select using (bucket_id = 'galerie');
create policy "lecture_publique_actualites" on storage.objects
  for select using (bucket_id = 'actualites');

-- Écriture (upload/suppression) réservée aux admins connectés
create policy "ecriture_admin_documents" on storage.objects
  for insert with check (bucket_id = 'documents' and public.est_admin());
create policy "maj_admin_documents" on storage.objects
  for update using (bucket_id = 'documents' and public.est_admin());
create policy "suppression_admin_documents" on storage.objects
  for delete using (bucket_id = 'documents' and public.est_admin());

create policy "ecriture_admin_galerie" on storage.objects
  for insert with check (bucket_id = 'galerie' and public.est_admin());
create policy "maj_admin_galerie" on storage.objects
  for update using (bucket_id = 'galerie' and public.est_admin());
create policy "suppression_admin_galerie" on storage.objects
  for delete using (bucket_id = 'galerie' and public.est_admin());

create policy "ecriture_admin_actualites" on storage.objects
  for insert with check (bucket_id = 'actualites' and public.est_admin());
create policy "maj_admin_actualites" on storage.objects
  for update using (bucket_id = 'actualites' and public.est_admin());
create policy "suppression_admin_actualites" on storage.objects
  for delete using (bucket_id = 'actualites' and public.est_admin());
