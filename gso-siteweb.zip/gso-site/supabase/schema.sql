-- =========================================================
-- Groupe Scolaire Les Oliviers — schéma Supabase
-- À exécuter dans l'Éditeur SQL de Supabase, dans l'ordre.
-- =========================================================

-- Extension utile pour les identifiants
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------
-- 1. UTILISATEURS (profils admin, liés à auth.users)
-- ---------------------------------------------------------
create table if not exists public.utilisateurs (
  id uuid primary key references auth.users (id) on delete cascade,
  nom text not null,
  role text not null default 'admin' check (role in ('admin', 'super_admin')),
  cree_le timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 2. PROGRAMMES (Congolais / Français) et niveaux
-- ---------------------------------------------------------
create table if not exists public.programmes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique, -- 'congolais' | 'francais'
  nom text not null,
  description text,
  ordre int not null default 0
);

create table if not exists public.niveaux (
  id uuid primary key default gen_random_uuid(),
  programme_id uuid not null references public.programmes (id) on delete cascade,
  cycle text not null,      -- Maternelle / Primaire / Collège / Lycée Général / Lycée Technique
  classe text not null,     -- ex. "Terminale S", "CM2"
  ordre int not null default 0
);

-- ---------------------------------------------------------
-- 3. TARIFS (administrables)
-- ---------------------------------------------------------
create table if not exists public.tarifs (
  id uuid primary key default gen_random_uuid(),
  programme_id uuid not null references public.programmes (id) on delete cascade,
  cycle text not null,
  inscription numeric,
  reinscription numeric,
  ecolage_mi_temps numeric,
  ecolage_plein_temps numeric,
  note text,
  maj_le timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 4. DOCUMENTS (fournitures + prospectus, gérés depuis l'admin)
-- ---------------------------------------------------------
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('fourniture', 'prospectus')),
  programme_id uuid references public.programmes (id) on delete set null,
  cycle text,
  classe text,
  titre text not null,
  description text,
  chemin_fichier text not null, -- chemin dans le bucket Supabase Storage
  cree_le timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 5. ACTUALITES
-- ---------------------------------------------------------
create table if not exists public.actualites (
  id uuid primary key default gen_random_uuid(),
  titre text not null,
  sous_titre text,
  resume text,
  contenu text,
  image_url text,
  auteur text,
  categorie text,
  statut text not null default 'brouillon' check (statut in ('brouillon', 'publie')),
  publie_le timestamptz,
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 6. GALERIE
-- ---------------------------------------------------------
create table if not exists public.galerie (
  id uuid primary key default gen_random_uuid(),
  categorie text not null, -- Évènements / Activités / Cérémonies / Infrastructures / Sorties pédagogiques / Vie scolaire
  titre text,
  image_url text not null,
  ordre int not null default 0,
  cree_le timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 7. INSCRIPTIONS (préinscriptions en ligne)
-- ---------------------------------------------------------
create table if not exists public.inscriptions (
  id uuid primary key default gen_random_uuid(),
  numero_dossier text unique,
  eleve_nom text not null,
  eleve_prenom text not null,
  eleve_sexe text not null check (eleve_sexe in ('M', 'F')),
  eleve_date_naissance date not null,
  eleve_etablissement_precedent text,
  parent_nom text not null,
  parent_prenom text not null,
  parent_telephone text not null,
  parent_email text,
  parent_adresse text,
  programme_id uuid references public.programmes (id),
  classe text not null,
  statut text not null default 'en_attente' check (statut in ('en_attente', 'validee', 'rejetee')),
  cree_le timestamptz not null default now()
);

-- Génération automatique d'un numéro de dossier unique (ex. GSO-2026-00001)
create sequence if not exists public.inscriptions_dossier_seq;

create or replace function public.generer_numero_dossier()
returns trigger
language plpgsql
as $$
begin
  if new.numero_dossier is null then
    new.numero_dossier := 'GSO-' || to_char(now(), 'YYYY') || '-' ||
      lpad(nextval('public.inscriptions_dossier_seq')::text, 5, '0');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_inscriptions_numero_dossier on public.inscriptions;
create trigger trg_inscriptions_numero_dossier
  before insert on public.inscriptions
  for each row execute function public.generer_numero_dossier();

-- RPC dédiée au formulaire public : insère la préinscription et renvoie
-- uniquement le numéro de dossier (le visiteur anonyme n'a pas accès en
-- lecture à la table inscriptions, réservée aux admins — voir RLS plus bas).
create or replace function public.creer_inscription(
  p_eleve_nom text,
  p_eleve_prenom text,
  p_eleve_sexe text,
  p_eleve_date_naissance date,
  p_eleve_etablissement_precedent text,
  p_parent_nom text,
  p_parent_prenom text,
  p_parent_telephone text,
  p_parent_email text,
  p_parent_adresse text,
  p_programme_id uuid,
  p_classe text
)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_numero text;
begin
  insert into public.inscriptions (
    eleve_nom, eleve_prenom, eleve_sexe, eleve_date_naissance,
    eleve_etablissement_precedent, parent_nom, parent_prenom,
    parent_telephone, parent_email, parent_adresse, programme_id, classe
  ) values (
    p_eleve_nom, p_eleve_prenom, p_eleve_sexe, p_eleve_date_naissance,
    p_eleve_etablissement_precedent, p_parent_nom, p_parent_prenom,
    p_parent_telephone, p_parent_email, p_parent_adresse, p_programme_id, p_classe
  )
  returning numero_dossier into v_numero;

  return v_numero;
end;
$$;

grant execute on function public.creer_inscription(
  text, text, text, date, text, text, text, text, text, text, uuid, text
) to anon, authenticated;

-- ---------------------------------------------------------
-- 8. CONTACTS (formulaire de contact)
-- ---------------------------------------------------------
create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  email text not null,
  telephone text,
  message text not null,
  lu boolean not null default false,
  cree_le timestamptz not null default now()
);

-- =========================================================
-- ROW LEVEL SECURITY
-- Règle générale : lecture publique sur le contenu destiné au
-- site (programmes, niveaux, tarifs, documents, actualités
-- publiées, galerie) ; écriture réservée aux admins connectés
-- (table utilisateurs). Inscriptions/contacts : dépôt public,
-- lecture réservée aux admins.
-- =========================================================

alter table public.utilisateurs enable row level security;
alter table public.programmes enable row level security;
alter table public.niveaux enable row level security;
alter table public.tarifs enable row level security;
alter table public.documents enable row level security;
alter table public.actualites enable row level security;
alter table public.galerie enable row level security;
alter table public.inscriptions enable row level security;
alter table public.contacts enable row level security;

-- Fonction utilitaire : l'utilisateur courant est-il un admin ?
create or replace function public.est_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from public.utilisateurs u where u.id = auth.uid()
  );
$$;

-- utilisateurs : un admin ne voit/gère que son propre profil
create policy "utilisateurs_self_select" on public.utilisateurs
  for select using (id = auth.uid());
create policy "utilisateurs_self_update" on public.utilisateurs
  for update using (id = auth.uid());

-- programmes / niveaux / tarifs / documents : lecture publique, écriture admin
create policy "programmes_public_read" on public.programmes
  for select using (true);
create policy "programmes_admin_write" on public.programmes
  for all using (public.est_admin()) with check (public.est_admin());

create policy "niveaux_public_read" on public.niveaux
  for select using (true);
create policy "niveaux_admin_write" on public.niveaux
  for all using (public.est_admin()) with check (public.est_admin());

create policy "tarifs_public_read" on public.tarifs
  for select using (true);
create policy "tarifs_admin_write" on public.tarifs
  for all using (public.est_admin()) with check (public.est_admin());

create policy "documents_public_read" on public.documents
  for select using (true);
create policy "documents_admin_write" on public.documents
  for all using (public.est_admin()) with check (public.est_admin());

-- actualites : lecture publique des articles publiés, admin voit/gère tout
create policy "actualites_public_read" on public.actualites
  for select using (statut = 'publie' or public.est_admin());
create policy "actualites_admin_write" on public.actualites
  for all using (public.est_admin()) with check (public.est_admin());

-- galerie : lecture publique, écriture admin
create policy "galerie_public_read" on public.galerie
  for select using (true);
create policy "galerie_admin_write" on public.galerie
  for all using (public.est_admin()) with check (public.est_admin());

-- inscriptions : dépôt public (insert), lecture/gestion réservée aux admins
create policy "inscriptions_public_insert" on public.inscriptions
  for insert with check (true);
create policy "inscriptions_admin_read" on public.inscriptions
  for select using (public.est_admin());
create policy "inscriptions_admin_update" on public.inscriptions
  for update using (public.est_admin());

-- contacts : dépôt public (insert), lecture réservée aux admins
create policy "contacts_public_insert" on public.contacts
  for insert with check (true);
create policy "contacts_admin_read" on public.contacts
  for select using (public.est_admin());
create policy "contacts_admin_update" on public.contacts
  for update using (public.est_admin());

-- =========================================================
-- Données de départ : programmes
-- =========================================================
insert into public.programmes (code, nom, ordre) values
  ('congolais', 'Programme Congolais', 1),
  ('francais', 'Programme Français', 2)
on conflict (code) do nothing;
