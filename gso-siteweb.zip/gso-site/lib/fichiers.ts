/**
 * Nettoie un nom de fichier pour qu'il soit accepté par Supabase Storage :
 * supprime les accents, remplace les espaces et caractères spéciaux par des
 * tirets, et ne garde que lettres/chiffres/points/tirets/underscores.
 */
export function nomFichierSur(nom: string): string {
  const sansAccents = nom
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, ""); // diacritiques (é -> e, etc.)

  return sansAccents
    .replace(/[^a-zA-Z0-9.\-_]+/g, "-") // tout le reste -> tiret
    .replace(/-+/g, "-") // pas de tirets consécutifs
    .replace(/^-|-$/g, ""); // pas de tiret en tête/queue
}
