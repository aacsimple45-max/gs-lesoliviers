import { createClient } from "@supabase/supabase-js";

// Client Supabase simple (lecture publique) pour les composants qui n'ont pas
// besoin de la gestion de session/cookies de @supabase/ssr.
export const supabaseClient = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);
