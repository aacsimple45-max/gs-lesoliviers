import Image from "next/image";

export default function Footer() {
  return (
    <footer className="bg-olive-900 text-ivory">
      <div className="container-gso grid gap-10 py-14 sm:grid-cols-3">
        <div>
          <div className="mb-3 flex items-center gap-3">
            <Image src="/images/logo.png" alt="GSO" width={44} height={44} className="h-11 w-11 object-contain" />
            <span className="font-display text-lg font-semibold text-gilt-400">Les Oliviers</span>
          </div>
          <p className="font-body text-sm text-ivory/70">Travail · Discipline · Réussite</p>
        </div>

        <div className="font-body text-sm text-ivory/80">
          <p className="mb-2 font-semibold text-gilt-400">Contact</p>
          <p>113 Bis, rue Matsiona Nzoulou (Arrêt Palmier)</p>
          <p>Batignolles, Brazzaville</p>
          <p className="mt-2">(+242) 06 807 73 09 / 05 366 57 19</p>
          <p>lesoliviers.gs@gmail.com</p>
        </div>

        <div className="font-body text-sm text-ivory/80">
          <p className="mb-2 font-semibold text-gilt-400">Liens utiles</p>
          <ul className="space-y-1">
            <li><a href="/fournitures" className="hover:text-gilt-400">Fournitures scolaires</a></li>
            <li><a href="/prospectus" className="hover:text-gilt-400">Prospectus</a></li>
            <li><a href="/tarifs" className="hover:text-gilt-400">Tarifs</a></li>
            <li><a href="/inscription" className="hover:text-gilt-400">Inscription en ligne</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ivory/10 bg-mustard-500 py-4 text-center font-body text-xs font-semibold text-olive-900">
        © {new Date().getFullYear()} Groupe Scolaire Les Oliviers — Tous droits réservés.
      </div>
    </footer>
  );
}
