import Image from "next/image";
import type { ReactNode } from "react";

export default function PageHero({
  image,
  alt,
  eyebrow,
  title,
  subtitle,
  children,
  height = "h-[60vh] min-h-[420px]",
}: {
  image: string;
  alt: string;
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children?: ReactNode;
  height?: string;
}) {
  return (
    <section className={`relative w-full ${height} overflow-hidden`}>
      <Image src={image} alt={alt} fill priority className="object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-olive-950/90 via-olive-950/50 to-olive-950/10" />
      <div className="container-gso relative z-10 flex h-full flex-col justify-end pb-12 sm:pb-16">
        {eyebrow && <span className="section-label text-gilt-400">{eyebrow}</span>}
        <h1 className="mt-2 max-w-2xl font-display text-3xl font-semibold text-ivory sm:text-4xl md:text-5xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-4 max-w-xl font-body text-ivory/85">{subtitle}</p>
        )}
        {children}
      </div>
    </section>
  );
}
