"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

const infoLinks = [
  { label: "Programmes", href: "/programmes" },
  { label: "Inscription", href: "/inscription" },
  { label: "Tarifs", href: "/tarifs" },
  { label: "Fournitures", href: "/fournitures" },
  { label: "Prospectus", href: "/prospectus" },
  { label: "Actualités", href: "/actualites" },
  { label: "Galerie", href: "/galerie" },
  { label: "Contact", href: "/contact" },
  { label: "Administration", href: "/admin/login" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 shadow-sm">
      {/* Bande 1 — logo + nom de l'établissement */}
      <div className="bg-olive-900">
        <div className="container-gso flex items-center gap-4 py-3">
          <Image
            src="/images/logo.png"
            alt="Groupe Scolaire Les Oliviers"
            width={56}
            height={56}
            className="h-14 w-14 object-contain"
          />
          <div className="font-display leading-tight">
            <span className="block text-xl font-semibold text-gilt-400">GSO</span>
            <span className="block text-sm text-ivory/90">Les Oliviers</span>
          </div>
        </div>
      </div>

      {/* Bande 2 — navigation */}
      <div className="bg-ivory/95 backdrop-blur">
        <div className="container-gso flex items-center justify-between py-3">
          <Link href="/" className="font-body text-sm font-semibold text-olive-700 hover:text-olive-900">
            Accueil
          </Link>

          <nav className="flex items-center gap-6">
            <div className="relative">
              <button
                onClick={() => setOpen((v) => !v)}
                onBlur={() => setTimeout(() => setOpen(false), 150)}
                className="flex items-center gap-1 font-body text-sm font-semibold text-olive-700 hover:text-olive-900"
                aria-expanded={open}
              >
                Informations
                <svg width="12" height="12" viewBox="0 0 12 12" className={`transition ${open ? "rotate-180" : ""}`}>
                  <path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                </svg>
              </button>
              {open && (
                <ul className="absolute right-0 top-full mt-2 w-56 rounded-xl border border-olive-100 bg-white py-2 shadow-card">
                  {infoLinks.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className="block px-4 py-2 font-body text-sm text-olive-700 hover:bg-olive-50 hover:text-olive-900"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <Link href="/inscription" className="btn-primary">
              Inscrire mon enfant
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
