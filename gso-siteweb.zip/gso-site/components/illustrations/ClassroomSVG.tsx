export default function ClassroomSVG({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 400 300" className={className} xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="300" fill="#f2f4ea" />
      {/* Tableau */}
      <rect x="40" y="30" width="220" height="80" rx="6" fill="#232b12" />
      <rect x="50" y="40" width="200" height="60" rx="3" fill="#41521f" />
      <line x1="70" y1="55" x2="180" y2="55" stroke="#faf8f2" strokeWidth="3" strokeLinecap="round" opacity="0.5" />
      <line x1="70" y1="70" x2="150" y2="70" stroke="#faf8f2" strokeWidth="3" strokeLinecap="round" opacity="0.5" />
      {/* Fenêtre */}
      <rect x="300" y="30" width="70" height="90" rx="4" fill="#e0ab2e" opacity="0.25" />
      <rect x="300" y="30" width="70" height="90" rx="4" fill="none" stroke="#c9a227" strokeWidth="3" />
      <line x1="335" y1="30" x2="335" y2="120" stroke="#c9a227" strokeWidth="3" />
      <line x1="300" y1="75" x2="370" y2="75" stroke="#c9a227" strokeWidth="3" />
      {/* Pupitres + élèves */}
      {[70, 160, 250].map((x, i) => (
        <g key={x}>
          <rect x={x} y="190" width="70" height="14" rx="3" fill="#7c8f4a" />
          <rect x={x + 8} y="204" width="6" height="30" fill="#41521f" />
          <rect x={x + 56} y="204" width="6" height="30" fill="#41521f" />
          {/* élève */}
          <circle cx={x + 35} cy="165" r="16" fill="#8a5a3c" />
          <rect x={x + 20} y="180" width="30" height="26" rx="8" fill={i === 0 ? "#c68f1c" : i === 1 ? "#556b2f" : "#9c6f16"} />
        </g>
      ))}
      {/* enseignant */}
      <circle cx="200" cy="150" r="14" fill="#6b4226" />
      <rect x="188" y="163" width="24" height="34" rx="8" fill="#232b12" />
    </svg>
  );
}
