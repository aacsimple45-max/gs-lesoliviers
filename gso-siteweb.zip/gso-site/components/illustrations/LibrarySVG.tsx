export default function LibrarySVG({ className }: { className?: string }) {
  const colors = ["#556b2f", "#c9a227", "#41521f", "#e0ab2e", "#7c8f4a", "#9c6f16"];
  return (
    <svg viewBox="0 0 400 300" className={className} xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="300" fill="#faf8f2" />
      {/* Étagères */}
      {[0, 1, 2].map((row) => (
        <g key={row}>
          <rect x="30" y={40 + row * 80} width="340" height="60" rx="4" fill="#dfe5c8" />
          {Array.from({ length: 22 }).map((_, i) => (
            <rect
              key={i}
              x={38 + i * 15}
              y={48 + row * 80}
              width="10"
              height={30 + ((i * 7 + row * 3) % 14)}
              fill={colors[(i + row) % colors.length]}
              rx="1"
            />
          ))}
        </g>
      ))}
      {/* Table de lecture */}
      <rect x="140" y="250" width="120" height="10" rx="3" fill="#41521f" />
      <rect x="150" y="260" width="8" height="25" fill="#232b12" />
      <rect x="242" y="260" width="8" height="25" fill="#232b12" />
    </svg>
  );
}
