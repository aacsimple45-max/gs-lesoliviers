export default function BuildingPlanSVG({ className }: { className?: string }) {
  const floors = [
    { label: "3e étage — Lycée + salle multimédia", y: 20 },
    { label: "2e étage — Collège + bibliothèque", y: 90 },
    { label: "1er étage — Primaire", y: 160 },
    { label: "RDC — Maternelle + Administration", y: 230 },
  ];
  return (
    <svg viewBox="0 0 500 340" className={className} xmlns="http://www.w3.org/2000/svg">
      <rect width="500" height="340" fill="#faf8f2" />
      {floors.map((f, i) => (
        <g key={f.label}>
          <rect
            x="40"
            y={f.y}
            width="300"
            height="60"
            rx="6"
            fill={i % 2 === 0 ? "#dfe5c8" : "#f2f4ea"}
            stroke="#7c8f4a"
            strokeWidth="1.5"
          />
          <text x="55" y={f.y + 34} fontSize="13" fill="#232b12" fontFamily="Inter, sans-serif">
            {f.label}
          </text>
        </g>
      ))}
      {/* Cour */}
      <rect x="360" y="20" width="110" height="270" rx="6" fill="#e0ab2e" opacity="0.2" stroke="#c9a227" strokeWidth="1.5" />
      <text x="415" y="150" fontSize="13" fill="#41521f" fontFamily="Inter, sans-serif" textAnchor="middle" transform="rotate(90 415 150)">
        Cour
      </text>
    </svg>
  );
}
