export default function MultimediaSVG({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 400 300" className={className} xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="300" fill="#f2f4ea" />
      {[0, 1].map((row) =>
        [0, 1, 2, 3].map((col) => {
          const x = 40 + col * 85;
          const y = 60 + row * 110;
          return (
            <g key={`${row}-${col}`}>
              {/* bureau */}
              <rect x={x} y={y + 55} width="70" height="10" rx="2" fill="#7c8f4a" />
              <rect x={x + 6} y={y + 65} width="6" height="24" fill="#41521f" />
              <rect x={x + 58} y={y + 65} width="6" height="24" fill="#41521f" />
              {/* écran */}
              <rect x={x + 15} y={y + 20} width="40" height="28" rx="3" fill="#232b12" />
              <rect x={x + 19} y={y + 24} width="32" height="20" rx="2" fill="#e0ab2e" opacity="0.85" />
              <rect x={x + 30} y={y + 48} width="10" height="6" fill="#232b12" />
            </g>
          );
        })
      )}
    </svg>
  );
}
