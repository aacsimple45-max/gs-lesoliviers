import type { MetadataRoute } from "next";
import { supabaseServer } from "@/lib/supabase-server";

const BASE_URL = "https://www.gsoliviers.com";

const pagesStatiques = [
  { path: "", priority: 1, frequence: "weekly" as const },
  { path: "/programmes", priority: 0.9, frequence: "monthly" as const },
  { path: "/programmes/congolais", priority: 0.8, frequence: "monthly" as const },
  { path: "/programmes/francais", priority: 0.8, frequence: "monthly" as const },
  { path: "/inscription", priority: 0.9, frequence: "monthly" as const },
  { path: "/tarifs", priority: 0.8, frequence: "monthly" as const },
  { path: "/fournitures", priority: 0.7, frequence: "yearly" as const },
  { path: "/prospectus", priority: 0.6, frequence: "yearly" as const },
  { path: "/actualites", priority: 0.6, frequence: "weekly" as const },
  { path: "/galerie", priority: 0.5, frequence: "monthly" as const },
  { path: "/contact", priority: 0.6, frequence: "yearly" as const },
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const entreesStatiques: MetadataRoute.Sitemap = pagesStatiques.map((p) => ({
    url: `${BASE_URL}${p.path}`,
    changeFrequency: p.frequence,
    priority: p.priority,
    lastModified: new Date(),
  }));

  let entreesArticles: MetadataRoute.Sitemap = [];
  try {
    const supabase = supabaseServer();
    const { data: articles } = await supabase
      .from("actualites")
      .select("id, publie_le")
      .eq("statut", "publie");

    entreesArticles = (articles ?? []).map((a) => ({
      url: `${BASE_URL}/actualites/${a.id}`,
      lastModified: a.publie_le ? new Date(a.publie_le) : new Date(),
      changeFrequency: "monthly",
      priority: 0.5,
    }));
  } catch {
    // Supabase non configuré au moment de la génération : on garde juste les pages statiques.
  }

  return [...entreesStatiques, ...entreesArticles];
}
