import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  metadataBase: new URL("https://www.gsoliviers.com"),
  title: {
    default: "Groupe Scolaire Les Oliviers — École privée à Brazzaville",
    template: "%s | Groupe Scolaire Les Oliviers",
  },
  description:
    "Groupe Scolaire Les Oliviers (GSO) : école privée à Brazzaville, programmes congolais et français, de la crèche au lycée. Travail, Discipline, Réussite.",
  keywords: [
    "Groupe Scolaire Les Oliviers",
    "École privée Brazzaville",
    "École française Brazzaville",
    "École congolaise Brazzaville",
    "Lycée privé Brazzaville",
    "Lycée technique Brazzaville",
  ],
  openGraph: {
    title: "Groupe Scolaire Les Oliviers — École privée à Brazzaville",
    description:
      "Travail, Discipline, Réussite. Inscriptions et réinscriptions ouvertes pour l'année scolaire 2026-2027.",
    url: "https://www.gsoliviers.com",
    siteName: "Groupe Scolaire Les Oliviers",
    images: ["/images/facade-ecole.png"],
    locale: "fr_CG",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Groupe Scolaire Les Oliviers — École privée à Brazzaville",
    description:
      "Travail, Discipline, Réussite. Inscriptions et réinscriptions ouvertes pour l'année scolaire 2026-2027.",
    images: ["/images/facade-ecole.png"],
  },
};

const jsonLdEcole = {
  "@context": "https://schema.org",
  "@type": "School",
  name: "Groupe Scolaire Les Oliviers",
  alternateName: "GSO",
  slogan: "Travail, Discipline, Réussite",
  url: "https://www.gsoliviers.com",
  logo: "https://www.gsoliviers.com/images/logo.png",
  image: "https://www.gsoliviers.com/images/facade-ecole.png",
  telephone: ["+242068077309", "+242053665719"],
  email: "lesoliviers.gs@gmail.com",
  address: {
    "@type": "PostalAddress",
    streetAddress: "113 Bis, rue Matsiona Nzoulou (Arrêt Palmier)",
    addressLocality: "Batignolles, Brazzaville",
    addressCountry: "CG",
  },
  areaServed: "Brazzaville",
  sameAs: [],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="font-body antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdEcole) }}
        />
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
