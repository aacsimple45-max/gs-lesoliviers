import type { Metadata } from "next";
import { tarifsData } from "@/data/tarifs";
import { supabaseServer } from "@/lib/supabase-server";

export const metadata: Metadata = {
  title: "Tarifs",
  description: "Grille tarifaire 2026-2027 du Groupe Scolaire Les Oliviers — inscription, réinscription et écolages.",
};

export const revalidate = 60;

function formatFrs(n: number | null | undefined) {
  if (n === null || n === undefined) return "—";
  return `${n.toLocaleString("fr-FR")} Frs`;
}

export default async function TarifsPage() {
  const supabase = supabaseServer();
  const { data: tarifsDB } = await supabase
    .from("tarifs")
    .select("*, programmes(nom)")
    .order("cycle");

  const utiliserDB = (tarifsDB?.length ?? 0) > 0;

  const grillesDB = utiliserDB
    ? Object.values(
        (tarifsDB ?? []).reduce((acc: Record<string, { programme: string; lignes: any[] }>, t: any) => {
          const nom = t.programmes?.nom ?? "Autre";
          if (!acc[nom]) acc[nom] = { programme: nom, lignes: [] };
          acc[nom].lignes.push(t);
          return acc;
        }, {})
      )
    : [];

  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Année scolaire 2026 – 2027</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">Tarifs</h1>

      {!utiliserDB && (
        <div className="mt-12 space-y-14">
          {tarifsData.map((grille) => (
            <div key={grille.programme}>
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <h2 className="font-display text-2xl font-semibold text-mustard-600">{grille.programme}</h2>
                <p className="font-body text-sm text-olive-900/70">
                  Inscription : <span className="font-semibold text-olive-900">{grille.inscriptionGenerale}</span>
                  {"  ·  "}Réinscription : <span className="font-semibold text-olive-900">{grille.reinscriptionGenerale}</span>
                </p>
              </div>

              <div className="mt-5 overflow-x-auto rounded-2xl border border-olive-100 shadow-card">
                <table className="w-full min-w-[520px] font-body text-sm">
                  <thead className="bg-olive-600 text-ivory">
                    <tr>
                      <th className="px-5 py-3 text-left font-semibold">Cycle / Classe</th>
                      <th className="px-5 py-3 text-left font-semibold">Écolage Mi-temps</th>
                      <th className="px-5 py-3 text-left font-semibold">Écolage Plein temps</th>
                    </tr>
                  </thead>
                  <tbody>
                    {grille.lignes.map((l, i) => (
                      <tr key={l.cycle} className={i % 2 ? "bg-olive-50" : "bg-white"}>
                        <td className="px-5 py-3 text-olive-900">
                          {l.cycle}
                          {l.note && <span className="ml-2 text-xs text-olive-900/50">({l.note})</span>}
                        </td>
                        <td className="px-5 py-3 text-olive-900">{l.miTemps}</td>
                        <td className="px-5 py-3 text-olive-900">{l.pleinTemps}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <ul className="mt-4 space-y-1 font-body text-xs text-olive-900/60">
                {grille.notes.map((n) => (
                  <li key={n}>· {n}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {utiliserDB && (
        <div className="mt-12 space-y-14">
          {grillesDB.map((grille: any) => (
            <div key={grille.programme}>
              <h2 className="font-display text-2xl font-semibold text-mustard-600">{grille.programme}</h2>
              <div className="mt-5 overflow-x-auto rounded-2xl border border-olive-100 shadow-card">
                <table className="w-full min-w-[600px] font-body text-sm">
                  <thead className="bg-olive-600 text-ivory">
                    <tr>
                      <th className="px-5 py-3 text-left font-semibold">Cycle / Classe</th>
                      <th className="px-5 py-3 text-left font-semibold">Inscription</th>
                      <th className="px-5 py-3 text-left font-semibold">Réinscription</th>
                      <th className="px-5 py-3 text-left font-semibold">Mi-temps</th>
                      <th className="px-5 py-3 text-left font-semibold">Plein temps</th>
                    </tr>
                  </thead>
                  <tbody>
                    {grille.lignes.map((l: any, i: number) => (
                      <tr key={l.id} className={i % 2 ? "bg-olive-50" : "bg-white"}>
                        <td className="px-5 py-3 text-olive-900">
                          {l.cycle}
                          {l.note && <span className="ml-2 text-xs text-olive-900/50">({l.note})</span>}
                        </td>
                        <td className="px-5 py-3 text-olive-900">{formatFrs(l.inscription)}</td>
                        <td className="px-5 py-3 text-olive-900">{formatFrs(l.reinscription)}</td>
                        <td className="px-5 py-3 text-olive-900">{formatFrs(l.ecolage_mi_temps)}</td>
                        <td className="px-5 py-3 text-olive-900">{formatFrs(l.ecolage_plein_temps)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      <p className="mt-14 font-body text-xs text-olive-900/50">
        Autres modes de paiement admis : Airtel Money 05 366 57 19 · Mobile Money 06 807 73 09 · BCH,
        compte n° 24201 1012000125258. Les frais d'inscription et de réinscription ne sont pas
        remboursables.
      </p>
    </div>
  );
}
