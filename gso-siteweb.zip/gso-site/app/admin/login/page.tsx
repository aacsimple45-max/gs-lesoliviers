"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase-browser";

export default function AdminLoginPage() {
  const router = useRouter();
  const supabase = supabaseBrowser();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErreur(null);
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    setLoading(false);
    if (error) {
      setErreur("Identifiants incorrects. Vérifiez votre email et votre mot de passe.");
      return;
    }
    router.push("/admin/dashboard");
    router.refresh();
  }

  return (
    <div className="container-gso flex min-h-[70vh] items-center justify-center py-20">
      <div className="w-full max-w-sm rounded-2xl border border-olive-100 bg-white p-8 shadow-card">
        <h1 className="font-display text-2xl font-semibold text-olive-900">Espace administration</h1>
        <p className="mt-1 font-body text-sm text-olive-900/60">Groupe Scolaire Les Oliviers</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label htmlFor="email" className="mb-1 block font-body text-sm font-medium text-olive-900">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm focus:border-olive-600 focus:outline-none"
              placeholder="admin@gsoliviers.com"
            />
          </div>

          <div>
            <label htmlFor="password" className="mb-1 block font-body text-sm font-medium text-olive-900">
              Mot de passe
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-olive-200 px-4 py-2 pr-16 font-body text-sm focus:border-olive-600 focus:outline-none"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 font-body text-xs font-semibold text-olive-600 hover:text-olive-800"
              >
                {showPassword ? "Masquer" : "Afficher"}
              </button>
            </div>
          </div>

          {erreur && <p className="font-body text-sm text-red-600">{erreur}</p>}

          <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
            {loading ? "Connexion..." : "Se connecter"}
          </button>
        </form>
      </div>
    </div>
  );
}
