"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase-browser";

type Programme = { id: string; code: string; nom: string };
type Tarif = {
  id: string;
  programme_id: string;
  cycle: string;
  inscription: number | null;
  reinscription: number | null;
  ecolage_mi_temps: number | null;
  ecolage_plein_temps: number | null;
  note: string | null;
};

const champVide = {
  programme_id: "",
  cycle: "",
  inscription: "",
  reinscription: "",
  ecolage_mi_temps: "",
  ecolage_plein_temps: "",
  note: "",
};

export default function AdminTarifsPage() {
  const supabase = supabaseBrowser();
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [tarifs, setTarifs] = useState<Tarif[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(champVide);
  const [enregistrement, setEnregistrement] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  async function charger() {
    setLoading(true);
    const [{ data: progs }, { data: tars }] = await Promise.all([
      supabase.from("programmes").select("id, code, nom").order("ordre"),
      supabase.from("tarifs").select("*").order("cycle"),
    ]);
    setProgrammes(progs ?? []);
    setTarifs(tars ?? []);
    setLoading(false);
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function nomProgramme(id: string) {
    return programmes.find((p) => p.id === id)?.nom ?? "—";
  }

  async function ajouter(e: React.FormEvent) {
    e.preventDefault();
    setErreur(null);
    if (!form.programme_id || !form.cycle) {
      setErreur("Programme et cycle sont obligatoires.");
      return;
    }
    setEnregistrement(true);
    const { error } = await supabase.from("tarifs").insert({
      programme_id: form.programme_id,
      cycle: form.cycle,
      inscription: form.inscription ? Number(form.inscription) : null,
      reinscription: form.reinscription ? Number(form.reinscription) : null,
      ecolage_mi_temps: form.ecolage_mi_temps ? Number(form.ecolage_mi_temps) : null,
      ecolage_plein_temps: form.ecolage_plein_temps ? Number(form.ecolage_plein_temps) : null,
      note: form.note || null,
    });
    setEnregistrement(false);
    if (error) {
      setErreur(error.message);
      return;
    }
    setForm(champVide);
    charger();
  }

  async function supprimer(id: string) {
    if (!confirm("Supprimer cette ligne tarifaire ?")) return;
    await supabase.from("tarifs").delete().eq("id", id);
    charger();
  }

  async function modifierChamp(id: string, champ: keyof Tarif, valeur: string) {
    const val = champ === "cycle" || champ === "note" ? (valeur || null) : (valeur ? Number(valeur) : null);
    setTarifs((prev) => prev.map((t) => (t.id === id ? { ...t, [champ]: val } : t)));
  }

  async function sauvegarderLigne(t: Tarif) {
    await supabase
      .from("tarifs")
      .update({
        cycle: t.cycle,
        inscription: t.inscription,
        reinscription: t.reinscription,
        ecolage_mi_temps: t.ecolage_mi_temps,
        ecolage_plein_temps: t.ecolage_plein_temps,
        note: t.note,
      })
      .eq("id", t.id);
  }

  return (
    <div className="container-gso py-14">
      <Link href="/admin/dashboard" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Retour au tableau de bord
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900">Tarifs</h1>
      <p className="mt-2 max-w-2xl font-body text-sm text-olive-900/60">
        Ces montants alimentent la page publique « Tarifs ». Tant qu'aucune ligne n'est ajoutée ici
        pour un programme, la page publique affiche la grille par défaut.
      </p>

      {/* Formulaire d'ajout */}
      <form onSubmit={ajouter} className="mt-8 grid gap-3 rounded-2xl border border-olive-100 bg-white p-6 shadow-card sm:grid-cols-3">
        <select
          value={form.programme_id}
          onChange={(e) => setForm({ ...form, programme_id: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm"
        >
          <option value="">Programme…</option>
          {programmes.map((p) => (
            <option key={p.id} value={p.id}>{p.nom}</option>
          ))}
        </select>
        <input
          placeholder="Cycle / classe"
          value={form.cycle}
          onChange={(e) => setForm({ ...form, cycle: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm"
        />
        <input
          placeholder="Inscription (Frs)"
          value={form.inscription}
          onChange={(e) => setForm({ ...form, inscription: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm"
        />
        <input
          placeholder="Réinscription (Frs)"
          value={form.reinscription}
          onChange={(e) => setForm({ ...form, reinscription: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm"
        />
        <input
          placeholder="Écolage mi-temps (Frs)"
          value={form.ecolage_mi_temps}
          onChange={(e) => setForm({ ...form, ecolage_mi_temps: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm"
        />
        <input
          placeholder="Écolage plein temps (Frs)"
          value={form.ecolage_plein_temps}
          onChange={(e) => setForm({ ...form, ecolage_plein_temps: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm"
        />
        <input
          placeholder="Note (optionnel)"
          value={form.note}
          onChange={(e) => setForm({ ...form, note: e.target.value })}
          className="rounded-lg border border-olive-200 px-3 py-2 font-body text-sm sm:col-span-2"
        />
        <button type="submit" disabled={enregistrement} className="btn-primary sm:col-span-1">
          {enregistrement ? "Ajout..." : "Ajouter la ligne"}
        </button>
        {erreur && <p className="font-body text-sm text-red-600 sm:col-span-3">{erreur}</p>}
      </form>

      {/* Liste */}
      <div className="mt-8 overflow-x-auto rounded-2xl border border-olive-100 shadow-card">
        <table className="w-full min-w-[900px] font-body text-sm">
          <thead className="bg-olive-600 text-ivory">
            <tr>
              <th className="px-4 py-3 text-left">Programme</th>
              <th className="px-4 py-3 text-left">Cycle</th>
              <th className="px-4 py-3 text-left">Inscription</th>
              <th className="px-4 py-3 text-left">Réinscription</th>
              <th className="px-4 py-3 text-left">Mi-temps</th>
              <th className="px-4 py-3 text-left">Plein temps</th>
              <th className="px-4 py-3 text-left">Note</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={8} className="px-4 py-6 text-center text-olive-900/50">Chargement…</td></tr>
            )}
            {!loading && tarifs.length === 0 && (
              <tr><td colSpan={8} className="px-4 py-6 text-center text-olive-900/50">Aucune ligne pour le moment.</td></tr>
            )}
            {tarifs.map((t, i) => (
              <tr key={t.id} className={i % 2 ? "bg-olive-50" : "bg-white"}>
                <td className="px-4 py-2 text-olive-900/70">{nomProgramme(t.programme_id)}</td>
                <td className="px-4 py-2">
                  <input
                    value={t.cycle}
                    onChange={(e) => modifierChamp(t.id, "cycle", e.target.value)}
                    onBlur={() => sauvegarderLigne(t)}
                    className="w-32 rounded border border-transparent bg-transparent px-1 py-0.5 hover:border-olive-200 focus:border-olive-400 focus:outline-none"
                  />
                </td>
                {(["inscription", "reinscription", "ecolage_mi_temps", "ecolage_plein_temps"] as const).map((champ) => (
                  <td key={champ} className="px-4 py-2">
                    <input
                      value={t[champ] ?? ""}
                      onChange={(e) => modifierChamp(t.id, champ, e.target.value)}
                      onBlur={() => sauvegarderLigne(t)}
                      className="w-24 rounded border border-transparent bg-transparent px-1 py-0.5 hover:border-olive-200 focus:border-olive-400 focus:outline-none"
                    />
                  </td>
                ))}
                <td className="px-4 py-2">
                  <input
                    value={t.note ?? ""}
                    onChange={(e) => modifierChamp(t.id, "note", e.target.value)}
                    onBlur={() => sauvegarderLigne(t)}
                    className="w-32 rounded border border-transparent bg-transparent px-1 py-0.5 hover:border-olive-200 focus:border-olive-400 focus:outline-none"
                  />
                </td>
                <td className="px-4 py-2 text-right">
                  <button onClick={() => supprimer(t.id)} className="font-body text-xs font-semibold text-red-600 hover:underline">
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
