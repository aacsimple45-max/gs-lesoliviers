"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { nomFichierSur } from "@/lib/fichiers";

type Programme = { id: string; code: string; nom: string };
type Document = {
  id: string;
  type: "fourniture" | "prospectus";
  programme_id: string | null;
  cycle: string | null;
  classe: string | null;
  titre: string;
  description: string | null;
  chemin_fichier: string;
  cree_le: string;
};

const champVide = {
  type: "fourniture" as "fourniture" | "prospectus",
  programme_id: "",
  cycle: "",
  classe: "",
  titre: "",
  description: "",
};

export default function AdminDocumentsPage() {
  const supabase = supabaseBrowser();
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(champVide);
  const [fichier, setFichier] = useState<File | null>(null);
  const [enregistrement, setEnregistrement] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  async function charger() {
    setLoading(true);
    const [{ data: progs }, { data: docs }] = await Promise.all([
      supabase.from("programmes").select("id, code, nom").order("ordre"),
      supabase.from("documents").select("*").order("cree_le", { ascending: false }),
    ]);
    setProgrammes(progs ?? []);
    setDocuments(docs ?? []);
    setLoading(false);
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function nomProgramme(id: string | null) {
    return programmes.find((p) => p.id === id)?.nom ?? "—";
  }

  async function ajouter(e: React.FormEvent) {
    e.preventDefault();
    setErreur(null);
    if (!form.titre || !fichier) {
      setErreur("Titre et fichier PDF sont obligatoires.");
      return;
    }
    setEnregistrement(true);

    const chemin = `${form.type}/${Date.now()}-${nomFichierSur(fichier.name)}`;
    const { error: uploadError } = await supabase.storage.from("documents").upload(chemin, fichier);
    if (uploadError) {
      setErreur(`Échec de l'upload : ${uploadError.message}`);
      setEnregistrement(false);
      return;
    }
    const { data: pub } = supabase.storage.from("documents").getPublicUrl(chemin);

    const { error } = await supabase.from("documents").insert({
      type: form.type,
      programme_id: form.programme_id || null,
      cycle: form.cycle || null,
      classe: form.classe || null,
      titre: form.titre,
      description: form.description || null,
      chemin_fichier: pub.publicUrl,
    });

    setEnregistrement(false);
    if (error) {
      setErreur(error.message);
      return;
    }
    setForm(champVide);
    setFichier(null);
    charger();
  }

  async function supprimer(id: string) {
    if (!confirm("Supprimer ce document ?")) return;
    await supabase.from("documents").delete().eq("id", id);
    charger();
  }

  return (
    <div className="container-gso py-14">
      <Link href="/admin/dashboard" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Retour au tableau de bord
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900">Documents</h1>
      <p className="mt-2 max-w-2xl font-body text-sm text-olive-900/60">
        Les fournitures et prospectus déjà en ligne sont des fichiers intégrés au site. Les documents
        ajoutés ici apparaissent en complément, dans une section dédiée des pages « Fournitures » et
        « Prospectus ».
      </p>

      <form onSubmit={ajouter} className="mt-8 grid gap-4 rounded-2xl border border-olive-100 bg-white p-6 shadow-card sm:grid-cols-2">
        <select
          value={form.type}
          onChange={(e) => setForm({ ...form, type: e.target.value as "fourniture" | "prospectus" })}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        >
          <option value="fourniture">Fourniture scolaire</option>
          <option value="prospectus">Prospectus</option>
        </select>
        <select
          value={form.programme_id}
          onChange={(e) => setForm({ ...form, programme_id: e.target.value })}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        >
          <option value="">Programme (optionnel)…</option>
          {programmes.map((p) => <option key={p.id} value={p.id}>{p.nom}</option>)}
        </select>
        <input
          placeholder="Cycle (ex. Primaire)"
          value={form.cycle}
          onChange={(e) => setForm({ ...form, cycle: e.target.value })}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        />
        <input
          placeholder="Classe (ex. CM2)"
          value={form.classe}
          onChange={(e) => setForm({ ...form, classe: e.target.value })}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        />
        <input
          placeholder="Titre du document"
          value={form.titre}
          onChange={(e) => setForm({ ...form, titre: e.target.value })}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm sm:col-span-2"
        />
        <textarea
          placeholder="Description (optionnel)"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          rows={2}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm sm:col-span-2"
        />
        <input
          type="file"
          accept="application/pdf"
          onChange={(e) => setFichier(e.target.files?.[0] ?? null)}
          className="font-body text-sm sm:col-span-2"
        />
        {erreur && <p className="font-body text-sm text-red-600 sm:col-span-2">{erreur}</p>}
        <button type="submit" disabled={enregistrement} className="btn-primary sm:col-span-2 disabled:opacity-60">
          {enregistrement ? "Envoi..." : "Ajouter le document"}
        </button>
      </form>

      <div className="mt-10 space-y-4">
        {loading && <p className="font-body text-sm text-olive-900/50">Chargement…</p>}
        {!loading && documents.length === 0 && (
          <p className="font-body text-sm text-olive-900/50">Aucun document ajouté depuis l'admin pour le moment.</p>
        )}
        {documents.map((doc) => (
          <div key={doc.id} className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-olive-100 bg-white p-5 shadow-card">
            <div>
              <span className="rounded-full bg-olive-100 px-3 py-1 font-body text-xs font-semibold text-olive-700">
                {doc.type === "fourniture" ? "Fourniture" : "Prospectus"}
              </span>
              <p className="mt-2 font-display text-base font-semibold text-olive-900">{doc.titre}</p>
              <p className="font-body text-xs text-olive-900/50">
                {nomProgramme(doc.programme_id)}{doc.cycle ? ` · ${doc.cycle}` : ""}{doc.classe ? ` · ${doc.classe}` : ""}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <a href={doc.chemin_fichier} target="_blank" rel="noopener noreferrer" className="btn-secondary !px-4 !py-2 text-xs">
                Consulter
              </a>
              <button onClick={() => supprimer(doc.id)} className="font-body text-xs font-semibold text-red-600 hover:underline">
                Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
