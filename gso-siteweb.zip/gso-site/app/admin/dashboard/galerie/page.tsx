"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { nomFichierSur } from "@/lib/fichiers";

type PhotoGalerie = {
  id: string;
  categorie: string;
  titre: string | null;
  image_url: string;
  ordre: number;
  cree_le: string;
};

const categories = [
  "Évènements",
  "Activités",
  "Cérémonies",
  "Infrastructures",
  "Sorties pédagogiques",
  "Vie scolaire",
];

export default function AdminGaleriePage() {
  const supabase = supabaseBrowser();
  const [items, setItems] = useState<PhotoGalerie[]>([]);
  const [loading, setLoading] = useState(true);
  const [titre, setTitre] = useState("");
  const [categorie, setCategorie] = useState(categories[0]);
  const [fichier, setFichier] = useState<File | null>(null);
  const [enregistrement, setEnregistrement] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  async function charger() {
    setLoading(true);
    const { data } = await supabase.from("galerie").select("*").order("cree_le", { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function ajouter(e: React.FormEvent) {
    e.preventDefault();
    setErreur(null);
    if (!fichier) {
      setErreur("Veuillez choisir une image.");
      return;
    }
    setEnregistrement(true);

    const chemin = `${Date.now()}-${nomFichierSur(fichier.name)}`;
    const { error: uploadError } = await supabase.storage.from("galerie").upload(chemin, fichier);
    if (uploadError) {
      setErreur(`Échec de l'upload : ${uploadError.message}`);
      setEnregistrement(false);
      return;
    }
    const { data: pub } = supabase.storage.from("galerie").getPublicUrl(chemin);

    const { error } = await supabase.from("galerie").insert({
      categorie,
      titre: titre || null,
      image_url: pub.publicUrl,
    });

    setEnregistrement(false);
    if (error) {
      setErreur(error.message);
      return;
    }
    setTitre("");
    setFichier(null);
    charger();
  }

  async function supprimer(item: PhotoGalerie) {
    if (!confirm("Supprimer cette photo ?")) return;
    await supabase.from("galerie").delete().eq("id", item.id);
    charger();
  }

  return (
    <div className="container-gso py-14">
      <Link href="/admin/dashboard" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Retour au tableau de bord
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900">Galerie</h1>

      <form onSubmit={ajouter} className="mt-8 grid gap-4 rounded-2xl border border-olive-100 bg-white p-6 shadow-card sm:grid-cols-2">
        <select
          value={categorie}
          onChange={(e) => setCategorie(e.target.value)}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        >
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <input
          placeholder="Légende (optionnel)"
          value={titre}
          onChange={(e) => setTitre(e.target.value)}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        />
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setFichier(e.target.files?.[0] ?? null)}
          className="font-body text-sm sm:col-span-2"
        />
        {erreur && <p className="font-body text-sm text-red-600 sm:col-span-2">{erreur}</p>}
        <button type="submit" disabled={enregistrement} className="btn-primary sm:col-span-2 disabled:opacity-60">
          {enregistrement ? "Envoi..." : "Ajouter à la galerie"}
        </button>
      </form>

      <div className="mt-10 grid gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {loading && <p className="font-body text-sm text-olive-900/50">Chargement…</p>}
        {!loading && items.length === 0 && (
          <p className="font-body text-sm text-olive-900/50">Aucune photo pour le moment.</p>
        )}
        {items.map((item) => (
          <div key={item.id} className="overflow-hidden rounded-2xl border border-olive-100 bg-white shadow-card">
            <div className="relative h-32 w-full">
              <Image src={item.image_url} alt={item.titre ?? item.categorie} fill className="object-cover" unoptimized />
            </div>
            <div className="p-3">
              <p className="font-body text-xs font-semibold uppercase tracking-wide text-mustard-600">{item.categorie}</p>
              {item.titre && <p className="mt-1 font-body text-sm text-olive-900">{item.titre}</p>}
              <button onClick={() => supprimer(item)} className="mt-2 font-body text-xs font-semibold text-red-600 hover:underline">
                Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
