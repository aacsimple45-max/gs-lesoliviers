"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { nomFichierSur } from "@/lib/fichiers";

type Actualite = {
  id: string;
  titre: string;
  sous_titre: string | null;
  resume: string | null;
  contenu: string | null;
  image_url: string | null;
  auteur: string | null;
  categorie: string | null;
  statut: "brouillon" | "publie";
  cree_le: string;
};

const champVide = {
  titre: "",
  sous_titre: "",
  resume: "",
  contenu: "",
  auteur: "",
  categorie: "",
};

export default function AdminActualitesPage() {
  const supabase = supabaseBrowser();
  const [items, setItems] = useState<Actualite[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(champVide);
  const [fichier, setFichier] = useState<File | null>(null);
  const [enregistrement, setEnregistrement] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  async function charger() {
    setLoading(true);
    const { data } = await supabase.from("actualites").select("*").order("cree_le", { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function publier(e: React.FormEvent) {
    e.preventDefault();
    setErreur(null);
    if (!form.titre) {
      setErreur("Le titre est obligatoire.");
      return;
    }
    setEnregistrement(true);

    let image_url: string | null = null;
    if (fichier) {
      const chemin = `${Date.now()}-${nomFichierSur(fichier.name)}`;
      const { error: uploadError } = await supabase.storage.from("actualites").upload(chemin, fichier);
      if (uploadError) {
        setErreur(`Échec de l'upload : ${uploadError.message}`);
        setEnregistrement(false);
        return;
      }
      const { data: pub } = supabase.storage.from("actualites").getPublicUrl(chemin);
      image_url = pub.publicUrl;
    }

    const { error } = await supabase.from("actualites").insert({
      titre: form.titre,
      sous_titre: form.sous_titre || null,
      resume: form.resume || null,
      contenu: form.contenu || null,
      auteur: form.auteur || null,
      categorie: form.categorie || null,
      image_url,
      statut: "brouillon",
    });

    setEnregistrement(false);
    if (error) {
      setErreur(error.message);
      return;
    }
    setForm(champVide);
    setFichier(null);
    charger();
  }

  async function basculerStatut(item: Actualite) {
    const nouveauStatut = item.statut === "publie" ? "brouillon" : "publie";
    setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, statut: nouveauStatut } : i)));
    await supabase
      .from("actualites")
      .update({ statut: nouveauStatut, publie_le: nouveauStatut === "publie" ? new Date().toISOString() : null })
      .eq("id", item.id);
  }

  async function supprimer(id: string) {
    if (!confirm("Supprimer définitivement cet article ?")) return;
    await supabase.from("actualites").delete().eq("id", id);
    charger();
  }

  return (
    <div className="container-gso py-14">
      <Link href="/admin/dashboard" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Retour au tableau de bord
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900">Actualités</h1>

      <form onSubmit={publier} className="mt-8 space-y-4 rounded-2xl border border-olive-100 bg-white p-6 shadow-card">
        <h2 className="font-display text-lg font-semibold text-olive-900">Nouvel article</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <input
            placeholder="Titre"
            value={form.titre}
            onChange={(e) => setForm({ ...form, titre: e.target.value })}
            className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
          />
          <input
            placeholder="Sous-titre"
            value={form.sous_titre}
            onChange={(e) => setForm({ ...form, sous_titre: e.target.value })}
            className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
          />
          <input
            placeholder="Auteur"
            value={form.auteur}
            onChange={(e) => setForm({ ...form, auteur: e.target.value })}
            className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
          />
          <input
            placeholder="Catégorie"
            value={form.categorie}
            onChange={(e) => setForm({ ...form, categorie: e.target.value })}
            className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
          />
        </div>
        <textarea
          placeholder="Résumé (affiché dans les listes)"
          value={form.resume}
          onChange={(e) => setForm({ ...form, resume: e.target.value })}
          rows={2}
          className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        />
        <textarea
          placeholder="Contenu complet"
          value={form.contenu}
          onChange={(e) => setForm({ ...form, contenu: e.target.value })}
          rows={5}
          className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        />
        <div>
          <label className="mb-1 block font-body text-sm font-medium text-olive-900">Image</label>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setFichier(e.target.files?.[0] ?? null)}
            className="font-body text-sm"
          />
        </div>

        {erreur && <p className="font-body text-sm text-red-600">{erreur}</p>}

        <button type="submit" disabled={enregistrement} className="btn-primary disabled:opacity-60">
          {enregistrement ? "Enregistrement..." : "Enregistrer en brouillon"}
        </button>
      </form>

      <div className="mt-10 space-y-4">
        {loading && <p className="font-body text-sm text-olive-900/50">Chargement…</p>}
        {!loading && items.length === 0 && (
          <p className="font-body text-sm text-olive-900/50">Aucun article pour le moment.</p>
        )}
        {items.map((item) => (
          <div key={item.id} className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-olive-100 bg-white p-5 shadow-card">
            <div>
              <p className="font-display text-base font-semibold text-olive-900">{item.titre}</p>
              <p className="mt-1 font-body text-xs text-olive-900/50">
                {item.categorie ?? "Sans catégorie"} · {new Date(item.cree_le).toLocaleDateString("fr-FR")}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`rounded-full px-3 py-1 text-xs font-semibold ${item.statut === "publie" ? "bg-olive-100 text-olive-700" : "bg-mustard-100 text-mustard-700"}`}>
                {item.statut === "publie" ? "Publié" : "Brouillon"}
              </span>
              <button onClick={() => basculerStatut(item)} className="btn-secondary !px-4 !py-2 text-xs">
                {item.statut === "publie" ? "Archiver" : "Publier"}
              </button>
              <button onClick={() => supprimer(item.id)} className="font-body text-xs font-semibold text-red-600 hover:underline">
                Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
