"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase-browser";

type Contact = {
  id: string;
  nom: string;
  email: string;
  telephone: string | null;
  message: string;
  lu: boolean;
  cree_le: string;
};

export default function AdminMessagesPage() {
  const supabase = supabaseBrowser();
  const [items, setItems] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);

  async function charger() {
    setLoading(true);
    const { data } = await supabase.from("contacts").select("*").order("cree_le", { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function marquerLu(item: Contact) {
    setItems((prev) => prev.map((c) => (c.id === item.id ? { ...c, lu: !c.lu } : c)));
    await supabase.from("contacts").update({ lu: !item.lu }).eq("id", item.id);
  }

  async function supprimer(id: string) {
    if (!confirm("Supprimer ce message ?")) return;
    await supabase.from("contacts").delete().eq("id", id);
    charger();
  }

  return (
    <div className="container-gso py-14">
      <Link href="/admin/dashboard" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Retour au tableau de bord
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900">Messages de contact</h1>

      <div className="mt-8 space-y-4">
        {loading && <p className="font-body text-sm text-olive-900/50">Chargement…</p>}
        {!loading && items.length === 0 && (
          <p className="font-body text-sm text-olive-900/50">Aucun message pour le moment.</p>
        )}
        {items.map((item) => (
          <div
            key={item.id}
            className={`rounded-2xl border p-5 shadow-card ${item.lu ? "border-olive-100 bg-white" : "border-mustard-300 bg-mustard-50"}`}
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-display text-base font-semibold text-olive-900">{item.nom}</p>
                <p className="font-body text-xs text-olive-900/50">
                  {item.email}{item.telephone ? ` · ${item.telephone}` : ""} · {new Date(item.cree_le).toLocaleString("fr-FR")}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button onClick={() => marquerLu(item)} className="btn-secondary !px-4 !py-2 text-xs">
                  {item.lu ? "Marquer non lu" : "Marquer lu"}
                </button>
                <button onClick={() => supprimer(item.id)} className="font-body text-xs font-semibold text-red-600 hover:underline">
                  Supprimer
                </button>
              </div>
            </div>
            <p className="mt-3 font-body text-sm text-olive-900/80">{item.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
