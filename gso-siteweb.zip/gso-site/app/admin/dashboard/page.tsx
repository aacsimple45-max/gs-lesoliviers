import { supabaseServer } from "@/lib/supabase-server";
import { redirect } from "next/navigation";
import LogoutButton from "@/components/LogoutButton";

const modules = [
  { titre: "Actualités", texte: "Ajouter, modifier, supprimer, publier ou archiver.", href: "/admin/dashboard/actualites" },
  { titre: "Galerie", texte: "Uploader et organiser les photos par catégorie.", href: "/admin/dashboard/galerie" },
  { titre: "Documents", texte: "Fournitures et prospectus : upload, suppression, remplacement.", href: "/admin/dashboard/documents" },
  { titre: "Tarifs", texte: "Modifier les montants d'inscription et d'écolage.", href: "/admin/dashboard/tarifs" },
  { titre: "Préinscriptions", texte: "Consulter, valider et exporter les inscriptions.", href: "/admin/dashboard/inscriptions" },
  { titre: "Messages", texte: "Consulter les messages reçus via le formulaire de contact.", href: "/admin/dashboard/messages" },
];

export default async function AdminDashboardPage() {
  const supabase = supabaseServer();
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session) redirect("/admin/login");

  const { count: inscriptionsEnAttente } = await supabase
    .from("inscriptions")
    .select("*", { count: "exact", head: true })
    .eq("statut", "en_attente");

  const { count: messagesNonLus } = await supabase
    .from("contacts")
    .select("*", { count: "exact", head: true })
    .eq("lu", false);

  return (
    <div className="container-gso py-14">
      <div className="flex items-center justify-between">
        <div>
          <span className="section-label">Administration</span>
          <h1 className="mt-1 font-display text-3xl font-semibold text-olive-900">Tableau de bord</h1>
        </div>
        <LogoutButton />
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-olive-100 bg-white p-5 shadow-card">
          <p className="font-body text-sm text-olive-900/60">Préinscriptions en attente</p>
          <p className="mt-1 font-display text-3xl font-semibold text-mustard-600">
            {inscriptionsEnAttente ?? 0}
          </p>
        </div>
        <div className="rounded-2xl border border-olive-100 bg-white p-5 shadow-card">
          <p className="font-body text-sm text-olive-900/60">Messages de contact non lus</p>
          <p className="mt-1 font-display text-3xl font-semibold text-mustard-600">
            {messagesNonLus ?? 0}
          </p>
        </div>
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {modules.map((m) => (
          <a
            key={m.href}
            href={m.href}
            className="rounded-2xl border border-olive-100 bg-white p-6 shadow-card transition hover:border-olive-300"
          >
            <h2 className="font-display text-lg font-semibold text-olive-900">{m.titre}</h2>
            <p className="mt-2 font-body text-sm text-olive-900/70">{m.texte}</p>
          </a>
        ))}
      </div>
    </div>
  );
}
