"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase-browser";

type Inscription = {
  id: string;
  numero_dossier: string | null;
  eleve_nom: string;
  eleve_prenom: string;
  eleve_sexe: string;
  eleve_date_naissance: string;
  eleve_etablissement_precedent: string | null;
  parent_nom: string;
  parent_prenom: string;
  parent_telephone: string;
  parent_email: string | null;
  parent_adresse: string | null;
  classe: string;
  statut: "en_attente" | "validee" | "rejetee";
  cree_le: string;
  programmes: { nom: string } | null;
};

const statutLabel: Record<string, string> = {
  en_attente: "En attente",
  validee: "Validée",
  rejetee: "Rejetée",
};

const statutStyle: Record<string, string> = {
  en_attente: "bg-mustard-100 text-mustard-700",
  validee: "bg-olive-100 text-olive-700",
  rejetee: "bg-red-100 text-red-700",
};

export default function AdminInscriptionsPage() {
  const supabase = supabaseBrowser();
  const [items, setItems] = useState<Inscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtreStatut, setFiltreStatut] = useState<string>("tous");
  const [recherche, setRecherche] = useState("");

  async function charger() {
    setLoading(true);
    const { data } = await supabase
      .from("inscriptions")
      .select("*, programmes(nom)")
      .order("cree_le", { ascending: false });
    setItems((data as unknown as Inscription[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    charger();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function changerStatut(id: string, statut: Inscription["statut"]) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, statut } : i)));
    await supabase.from("inscriptions").update({ statut }).eq("id", id);
  }

  const filtres = useMemo(() => {
    return items.filter((i) => {
      if (filtreStatut !== "tous" && i.statut !== filtreStatut) return false;
      if (recherche.trim()) {
        const q = recherche.toLowerCase();
        const hay = `${i.numero_dossier} ${i.eleve_nom} ${i.eleve_prenom} ${i.parent_nom} ${i.parent_prenom} ${i.classe}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [items, filtreStatut, recherche]);

  function exporterCSV() {
    const entetes = [
      "Numero dossier", "Nom eleve", "Prenom eleve", "Sexe", "Date naissance",
      "Etablissement precedent", "Nom parent", "Prenom parent", "Telephone", "Email",
      "Adresse", "Programme", "Classe", "Statut", "Date de depot",
    ];
    const lignes = filtres.map((i) => [
      i.numero_dossier, i.eleve_nom, i.eleve_prenom, i.eleve_sexe, i.eleve_date_naissance,
      i.eleve_etablissement_precedent ?? "", i.parent_nom, i.parent_prenom, i.parent_telephone,
      i.parent_email ?? "", i.parent_adresse ?? "", i.programmes?.nom ?? "", i.classe,
      statutLabel[i.statut], new Date(i.cree_le).toLocaleDateString("fr-FR"),
    ]);
    const csv = [entetes, ...lignes]
      .map((l) => l.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(";"))
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `preinscriptions-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container-gso py-14">
      <Link href="/admin/dashboard" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Retour au tableau de bord
      </Link>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-semibold text-olive-900">Préinscriptions</h1>
        <button onClick={exporterCSV} className="btn-secondary !px-4 !py-2 text-sm">
          Exporter en CSV
        </button>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <input
          placeholder="Rechercher (nom, dossier, classe...)"
          value={recherche}
          onChange={(e) => setRecherche(e.target.value)}
          className="w-64 rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        />
        <select
          value={filtreStatut}
          onChange={(e) => setFiltreStatut(e.target.value)}
          className="rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
        >
          <option value="tous">Tous les statuts</option>
          <option value="en_attente">En attente</option>
          <option value="validee">Validée</option>
          <option value="rejetee">Rejetée</option>
        </select>
      </div>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-olive-100 shadow-card">
        <table className="w-full min-w-[1000px] font-body text-sm">
          <thead className="bg-olive-600 text-ivory">
            <tr>
              <th className="px-4 py-3 text-left">Dossier</th>
              <th className="px-4 py-3 text-left">Élève</th>
              <th className="px-4 py-3 text-left">Classe</th>
              <th className="px-4 py-3 text-left">Parent / Contact</th>
              <th className="px-4 py-3 text-left">Déposé le</th>
              <th className="px-4 py-3 text-left">Statut</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={6} className="px-4 py-6 text-center text-olive-900/50">Chargement…</td></tr>
            )}
            {!loading && filtres.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-6 text-center text-olive-900/50">Aucune préinscription.</td></tr>
            )}
            {filtres.map((i, idx) => (
              <tr key={i.id} className={idx % 2 ? "bg-olive-50" : "bg-white"}>
                <td className="px-4 py-3 font-semibold text-olive-900">{i.numero_dossier ?? "—"}</td>
                <td className="px-4 py-3 text-olive-900">
                  {i.eleve_prenom} {i.eleve_nom}
                  <div className="text-xs text-olive-900/50">{i.eleve_sexe} · né(e) le {new Date(i.eleve_date_naissance).toLocaleDateString("fr-FR")}</div>
                </td>
                <td className="px-4 py-3 text-olive-900/80">
                  {i.classe}
                  <div className="text-xs text-olive-900/50">{i.programmes?.nom}</div>
                </td>
                <td className="px-4 py-3 text-olive-900/80">
                  {i.parent_prenom} {i.parent_nom}
                  <div className="text-xs text-olive-900/50">{i.parent_telephone}{i.parent_email ? ` · ${i.parent_email}` : ""}</div>
                </td>
                <td className="px-4 py-3 text-olive-900/70">{new Date(i.cree_le).toLocaleDateString("fr-FR")}</td>
                <td className="px-4 py-3">
                  <select
                    value={i.statut}
                    onChange={(e) => changerStatut(i.id, e.target.value as Inscription["statut"])}
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${statutStyle[i.statut]}`}
                  >
                    <option value="en_attente">En attente</option>
                    <option value="validee">Validée</option>
                    <option value="rejetee">Rejetée</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
