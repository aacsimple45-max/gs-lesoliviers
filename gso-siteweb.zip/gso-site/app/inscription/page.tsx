"use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase-browser";

const programmes = [
  {
    code: "congolais",
    label: "Programme Congolais",
    classes: [
      "Crèche", "P1 (3 ans)", "P2 (4 ans)", "P3 (5 ans)",
      "CP1", "CP2", "CE1", "CE2", "CM1", "CM2",
      "6e", "5e", "4e", "3e",
      "Seconde (Tronc Commun)", "Première A", "Terminale A",
      "Première S", "Terminale S",
      "Seconde Commerciale (Tronc Commun)",
      "Première G1", "Première G2", "Première G3", "Première BG", "Première H",
      "Terminale G1", "Terminale G2", "Terminale G3", "Terminale BG", "Terminale H",
    ],
  },
  {
    code: "francais",
    label: "Programme Français",
    classes: ["TPS", "PS", "MS", "GS", "CP", "CE1", "CE2", "CM1", "CM2"],
  },
];

export default function InscriptionPage() {
  const supabase = supabaseBrowser();
  const [programme, setProgramme] = useState(programmes[0].code);
  const [envoi, setEnvoi] = useState<"idle" | "loading" | "ok" | "erreur">("idle");
  const [programmeIds, setProgrammeIds] = useState<Record<string, string>>({});
  const [numeroDossier, setNumeroDossier] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from("programmes")
      .select("id, code")
      .then(({ data }) => {
        if (data) {
          const map: Record<string, string> = {};
          data.forEach((p) => (map[p.code] = p.id));
          setProgrammeIds(map);
        }
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const classesDisponibles = programmes.find((p) => p.code === programme)?.classes ?? [];

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setEnvoi("loading");

    const form = new FormData(e.currentTarget);

    const { data, error } = await supabase.rpc("creer_inscription", {
      p_eleve_nom: form.get("eleve_nom"),
      p_eleve_prenom: form.get("eleve_prenom"),
      p_eleve_sexe: form.get("eleve_sexe"),
      p_eleve_date_naissance: form.get("eleve_date_naissance"),
      p_eleve_etablissement_precedent: form.get("eleve_etablissement_precedent") || null,
      p_parent_nom: form.get("parent_nom"),
      p_parent_prenom: form.get("parent_prenom"),
      p_parent_telephone: form.get("parent_telephone"),
      p_parent_email: form.get("parent_email") || null,
      p_parent_adresse: form.get("parent_adresse") || null,
      p_programme_id: programmeIds[programme] ?? null,
      p_classe: form.get("classe"),
    });

    if (error) {
      setEnvoi("erreur");
      return;
    }

    setNumeroDossier(typeof data === "string" ? data : null);
    setEnvoi("ok");
    (e.target as HTMLFormElement).reset();
  }

  if (envoi === "ok") {
    return (
      <div className="container-gso py-20 text-center">
        <h1 className="font-display text-3xl font-semibold text-olive-900">Demande envoyée</h1>
        <p className="mt-4 font-body text-olive-900/70">
          Votre préinscription a bien été enregistrée. Notre équipe vous contactera pour la
          confirmer et finaliser le dossier.
        </p>
        {numeroDossier && (
          <div className="mx-auto mt-6 inline-block rounded-xl border border-olive-200 bg-olive-50 px-6 py-4">
            <p className="font-body text-sm text-olive-900/60">Votre numéro de dossier</p>
            <p className="mt-1 font-display text-2xl font-semibold text-olive-900">{numeroDossier}</p>
          </div>
        )}
        <p className="mt-4 font-body text-sm text-olive-900/50">
          Conservez ce numéro : il vous sera demandé lors du dépôt des pièces à l&apos;école.
        </p>
      </div>
    );
  }

  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Rentrée 2026 – 2027</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">
        Inscription en ligne
      </h1>
      <p className="mt-4 max-w-2xl font-body text-olive-900/70">
        Ce formulaire enregistre une préinscription. Elle sera confirmée par l'administration, qui
        vous contactera pour les documents à fournir et le règlement des frais.
      </p>

      <form onSubmit={handleSubmit} className="mt-10 max-w-2xl space-y-8">
        <fieldset className="space-y-4">
          <legend className="font-display text-lg font-semibold text-olive-900">Élève</legend>
          <div className="grid gap-4 sm:grid-cols-2">
            <Champ label="Nom" name="eleve_nom" required />
            <Champ label="Prénom" name="eleve_prenom" required />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block font-body text-sm font-medium text-olive-900">Sexe</label>
              <select name="eleve_sexe" required className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm">
                <option value="">Sélectionner</option>
                <option value="M">Masculin</option>
                <option value="F">Féminin</option>
              </select>
            </div>
            <Champ label="Date de naissance" name="eleve_date_naissance" type="date" required />
          </div>
          <Champ label="Établissement précédent" name="eleve_etablissement_precedent" />
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="font-display text-lg font-semibold text-olive-900">Parent / Tuteur</legend>
          <div className="grid gap-4 sm:grid-cols-2">
            <Champ label="Nom" name="parent_nom" required />
            <Champ label="Prénom" name="parent_prenom" required />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Champ label="Téléphone" name="parent_telephone" required />
            <Champ label="Email" name="parent_email" type="email" />
          </div>
          <Champ label="Adresse" name="parent_adresse" />
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="font-display text-lg font-semibold text-olive-900">Programme & classe</legend>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block font-body text-sm font-medium text-olive-900">Programme</label>
              <select
                value={programme}
                onChange={(e) => setProgramme(e.target.value)}
                className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm"
              >
                {programmes.map((p) => (
                  <option key={p.code} value={p.code}>{p.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block font-body text-sm font-medium text-olive-900">Classe</label>
              <select name="classe" required className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm">
                <option value="">Sélectionner</option>
                {classesDisponibles.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>
        </fieldset>

        {envoi === "erreur" && (
          <p className="font-body text-sm text-red-600">
            Une erreur est survenue. Merci de réessayer ou de nous contacter directement.
          </p>
        )}

        <button type="submit" disabled={envoi === "loading"} className="btn-primary disabled:opacity-60">
          {envoi === "loading" ? "Envoi..." : "Envoyer ma préinscription"}
        </button>
      </form>
    </div>
  );
}

function Champ({
  label,
  name,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-1 block font-body text-sm font-medium text-olive-900">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm focus:border-olive-600 focus:outline-none"
      />
    </div>
  );
}
