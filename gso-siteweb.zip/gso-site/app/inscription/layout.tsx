import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Inscription en ligne",
  description:
    "Inscrivez votre enfant au Groupe Scolaire Les Oliviers pour l'année scolaire 2026-2027 : formulaire d'inscription en ligne, Programme Congolais et Programme Français, de la crèche au lycée.",
};

export default function InscriptionLayout({ children }: { children: React.ReactNode }) {
  return children;
}
