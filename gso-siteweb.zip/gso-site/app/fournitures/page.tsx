import type { Metadata } from "next";
import { fournituresData } from "@/data/fournitures";
import { supabaseServer } from "@/lib/supabase-server";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Fournitures scolaires",
  description:
    "Listes de fournitures scolaires 2026-2027 du Groupe Scolaire Les Oliviers, par programme, cycle et classe.",
};

export default async function FournituresPage() {
  const supabase = supabaseServer();
  const { data: docsComplementaires } = await supabase
    .from("documents")
    .select("*")
    .eq("type", "fourniture")
    .order("cree_le", { ascending: false });
  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Bibliothèque de documents</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">
        Fournitures scolaires 2026 – 2027
      </h1>
      <p className="mt-4 max-w-2xl font-body text-olive-900/70">
        Retrouvez la liste des fournitures pour chaque classe, au programme congolais comme au
        programme français. La série S regroupe désormais les anciennes séries C et D au Lycée
        Général.
      </p>

      <div className="mt-12 space-y-16">
        {fournituresData.map((programme) => (
          <div key={programme.programme}>
            <h2 className="font-display text-2xl font-semibold text-mustard-600">{programme.label}</h2>
            <div className="mt-6 space-y-10">
              {programme.cycles.map((cycle) => (
                <div key={cycle.cycle}>
                  <h3 className="font-body text-sm font-semibold uppercase tracking-wide text-olive-700">
                    {cycle.cycle}
                  </h3>
                  <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {cycle.items.map((item) => (
                      <div
                        key={item.classe}
                        className="flex flex-col justify-between rounded-2xl border border-olive-100 bg-white p-5 shadow-card"
                      >
                        <div>
                          <p className="font-display text-base font-semibold text-olive-900">{item.classe}</p>
                          {item.note && (
                            <p className="mt-1 font-body text-xs text-olive-900/60">{item.note}</p>
                          )}
                        </div>
                        <div className="mt-4 flex gap-3">
                          <a href={item.fichier} target="_blank" rel="noopener noreferrer" className="btn-secondary flex-1 !px-4 !py-2 text-xs">
                            Consulter
                          </a>
                          <a href={item.fichier} download className="btn-primary flex-1 !px-4 !py-2 text-xs">
                            Télécharger
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {docsComplementaires && docsComplementaires.length > 0 && (
        <div className="mt-16 border-t border-olive-100 pt-10">
          <h2 className="font-display text-xl font-semibold text-olive-900">Documents complémentaires</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {docsComplementaires.map((doc) => (
              <div key={doc.id} className="flex flex-col justify-between rounded-2xl border border-olive-100 bg-white p-5 shadow-card">
                <div>
                  <p className="font-display text-base font-semibold text-olive-900">{doc.titre}</p>
                  {doc.description && <p className="mt-1 font-body text-xs text-olive-900/60">{doc.description}</p>}
                </div>
                <div className="mt-4 flex gap-3">
                  <a href={doc.chemin_fichier} target="_blank" rel="noopener noreferrer" className="btn-secondary flex-1 !px-4 !py-2 text-xs">
                    Consulter
                  </a>
                  <a href={doc.chemin_fichier} download className="btn-primary flex-1 !px-4 !py-2 text-xs">
                    Télécharger
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
