import type { Metadata } from "next";
import { prospectusData } from "@/data/prospectus";
import { supabaseServer } from "@/lib/supabase-server";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Prospectus",
  description: "Prospectus du Groupe Scolaire Les Oliviers — programme congolais, programme français et Lycée Technique.",
};

export default async function ProspectusPage() {
  const supabase = supabaseServer();
  const { data: docsComplementaires } = await supabase
    .from("documents")
    .select("*")
    .eq("type", "prospectus")
    .order("cree_le", { ascending: false });
  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Bibliothèque de documents</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">Prospectus</h1>
      <p className="mt-4 max-w-2xl font-body text-olive-900/70">
        Rentrée scolaire 2026 – 2027. Consultez et téléchargez le prospectus de chaque programme.
      </p>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {prospectusData.map((p) => (
          <div key={p.fichier} className="flex flex-col justify-between rounded-2xl border border-olive-100 bg-white p-6 shadow-card">
            <div>
              <h2 className="font-display text-lg font-semibold text-olive-900">{p.titre}</h2>
              <p className="mt-2 font-body text-sm text-olive-900/70">{p.description}</p>
            </div>
            <div className="mt-6 flex gap-3">
              <a href={p.fichier} target="_blank" rel="noopener noreferrer" className="btn-secondary flex-1 !px-4 !py-2 text-xs">
                Consulter
              </a>
              <a href={p.fichier} download className="btn-primary flex-1 !px-4 !py-2 text-xs">
                Télécharger
              </a>
            </div>
          </div>
        ))}
      </div>

      {docsComplementaires && docsComplementaires.length > 0 && (
        <div className="mt-16 border-t border-olive-100 pt-10">
          <h2 className="font-display text-xl font-semibold text-olive-900">Documents complémentaires</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {docsComplementaires.map((doc) => (
              <div key={doc.id} className="flex flex-col justify-between rounded-2xl border border-olive-100 bg-white p-6 shadow-card">
                <div>
                  <h3 className="font-display text-lg font-semibold text-olive-900">{doc.titre}</h3>
                  {doc.description && <p className="mt-2 font-body text-sm text-olive-900/70">{doc.description}</p>}
                </div>
                <div className="mt-6 flex gap-3">
                  <a href={doc.chemin_fichier} target="_blank" rel="noopener noreferrer" className="btn-secondary flex-1 !px-4 !py-2 text-xs">
                    Consulter
                  </a>
                  <a href={doc.chemin_fichier} download className="btn-primary flex-1 !px-4 !py-2 text-xs">
                    Télécharger
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
