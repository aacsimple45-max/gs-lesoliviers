"use client";

import { useState } from "react";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { supabaseBrowser } from "@/lib/supabase-browser";
import BuildingPlanSVG from "@/components/illustrations/BuildingPlanSVG";

export default function ContactPage() {
  const supabase = supabaseBrowser();
  const [envoi, setEnvoi] = useState<"idle" | "loading" | "ok" | "erreur">("idle");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setEnvoi("loading");
    const form = new FormData(e.currentTarget);

    const { error } = await supabase.from("contacts").insert({
      nom: form.get("nom"),
      email: form.get("email"),
      telephone: form.get("telephone") || null,
      message: form.get("message"),
    });

    setEnvoi(error ? "erreur" : "ok");
    if (!error) (e.target as HTMLFormElement).reset();
  }

  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Contact</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">
        Une question ? Contactez-nous
      </h1>

      <div className="mt-10 grid gap-10 lg:grid-cols-2">
        <div>
          <div className="space-y-4 font-body text-olive-900/80">
            <p className="flex items-start gap-3">
              <MapPin className="mt-0.5 h-5 w-5 flex-shrink-0 text-mustard-600" />
              113 Bis, rue Matsiona Nzoulou (Arrêt Palmier), Batignolles, Brazzaville
            </p>
            <p className="flex items-center gap-3">
              <Phone className="h-5 w-5 flex-shrink-0 text-mustard-600" />
              (+242) 06 807 73 09 / 05 366 57 19
            </p>
            <p className="flex items-center gap-3">
              <Mail className="h-5 w-5 flex-shrink-0 text-mustard-600" />
              lesoliviers.gs@gmail.com
            </p>
            <p className="flex items-start gap-3">
              <Clock className="mt-0.5 h-5 w-5 flex-shrink-0 text-mustard-600" />
              Du lundi au jeudi : 7h00 – 16h00 · Vendredi : 7h00 – 12h00
            </p>
          </div>

          <div className="mt-8 overflow-hidden rounded-2xl border border-olive-100 shadow-card">
            <iframe
              title="Localisation du Groupe Scolaire Les Oliviers"
              src="https://www.google.com/maps?q=113+Bis+rue+Matsiona+Nzoulou+Batignolles+Brazzaville&output=embed"
              width="100%"
              height="280"
              style={{ border: 0 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <div className="mt-8 overflow-hidden rounded-2xl border border-olive-100 bg-white shadow-card">
            <BuildingPlanSVG className="h-auto w-full" />
          </div>
        </div>

        <div>
          {envoi === "ok" ? (
            <div className="rounded-2xl border border-olive-100 bg-olive-50 p-8 text-center">
              <h2 className="font-display text-xl font-semibold text-olive-900">Message envoyé</h2>
              <p className="mt-2 font-body text-sm text-olive-900/70">
                Merci, votre message a bien été reçu. Nous vous répondrons dans les meilleurs délais.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-olive-100 bg-white p-6 shadow-card sm:p-8">
              <div>
                <label htmlFor="nom" className="mb-1 block font-body text-sm font-medium text-olive-900">Nom</label>
                <input id="nom" name="nom" required className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm focus:border-olive-600 focus:outline-none" />
              </div>
              <div>
                <label htmlFor="email" className="mb-1 block font-body text-sm font-medium text-olive-900">Email</label>
                <input id="email" name="email" type="email" required className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm focus:border-olive-600 focus:outline-none" />
              </div>
              <div>
                <label htmlFor="telephone" className="mb-1 block font-body text-sm font-medium text-olive-900">Téléphone</label>
                <input id="telephone" name="telephone" className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm focus:border-olive-600 focus:outline-none" />
              </div>
              <div>
                <label htmlFor="message" className="mb-1 block font-body text-sm font-medium text-olive-900">Message</label>
                <textarea id="message" name="message" required rows={5} className="w-full rounded-lg border border-olive-200 px-4 py-2 font-body text-sm focus:border-olive-600 focus:outline-none" />
              </div>

              {envoi === "erreur" && (
                <p className="font-body text-sm text-red-600">
                  Une erreur est survenue. Merci de réessayer ou de nous appeler directement.
                </p>
              )}

              <button type="submit" disabled={envoi === "loading"} className="btn-primary w-full disabled:opacity-60">
                {envoi === "loading" ? "Envoi..." : "Envoyer le message"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
