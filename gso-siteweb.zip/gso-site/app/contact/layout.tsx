import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Contactez le Groupe Scolaire Les Oliviers à Batignolles, Brazzaville : adresse, téléphone, email, horaires, formulaire de contact et localisation.",
};

export default function ContactLayout({ children }: { children: React.ReactNode }) {
  return children;
}
