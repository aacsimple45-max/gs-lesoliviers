import Link from "next/link";
import type { Metadata } from "next";
import {
  GraduationCap,
  BookOpen,
  Users,
  ShieldCheck,
  Languages,
  Laptop,
  PartyPopper,
} from "lucide-react";
import PageHero from "@/components/PageHero";
import {
  evenements,
  atoutsEtablissement,
  pourquoiInscrire,
  methodesEnseignement,
} from "@/data/etablissement";

export const metadata: Metadata = {
  title: "Programmes",
  description:
    "Programme Congolais (crèche au Lycée Général et Technique) et Programme Français (crèche au CM2) au Groupe Scolaire Les Oliviers, école privée à Brazzaville.",
};

const valeurs = [
  { titre: "Suivi personnalisé", texte: "Un accompagnement individuel pour chaque élève, du préscolaire au lycée.", Icon: Users },
  { titre: "Anglais dès le CP", texte: "Initiation à la langue anglaise dès la classe de CP.", Icon: Languages },
  { titre: "Numérique dès le CE1", texte: "Salle multimédia équipée, accès Internet dès le CE1.", Icon: Laptop },
  { titre: "Encadrement sécurisé", texte: "Trousse de santé permanente, environnement propre et surveillé.", Icon: ShieldCheck },
];

export default function ProgrammesPage() {
  return (
    <div>
      <PageHero
        image="/images/facade-ecole.png"
        alt="Groupe Scolaire Les Oliviers"
        eyebrow="Nos programmes"
        title="Deux programmes, une même exigence de réussite"
        subtitle="Le Groupe Scolaire Les Oliviers accompagne les élèves de la crèche au lycée, au Programme Congolais comme au Programme Français."
        height="h-[45vh] min-h-[320px]"
      />

      {/* Les deux programmes */}
      <section className="container-gso py-16 sm:py-20">
        <div className="grid gap-6 sm:grid-cols-2">
          <div className="rounded-2xl border border-olive-100 bg-white p-8 shadow-card">
            <GraduationCap className="h-8 w-8 text-mustard-600" />
            <h2 className="mt-4 font-display text-2xl font-semibold text-olive-900">Programme Congolais</h2>
            <p className="mt-2 font-body text-olive-900/70">
              De la crèche au Lycée Général et Technique : préscolaire, primaire, collège, lycée
              général (séries A et S) et lycée technique (Secrétariat, Comptabilité, Marketing &
              Gestion Financière, Économie).
            </p>
            <Link href="/programmes/congolais" className="btn-primary mt-6 inline-flex">
              Découvrir le programme
            </Link>
          </div>
          <div className="rounded-2xl border border-olive-100 bg-white p-8 shadow-card">
            <BookOpen className="h-8 w-8 text-mustard-600" />
            <h2 className="mt-4 font-display text-2xl font-semibold text-olive-900">Programme Français</h2>
            <p className="mt-2 font-body text-olive-900/70">
              De la crèche au CM2 : Crèche, TPS, PS, MS, GS, puis primaire du CP au CM2, avec la
              méthodologie et les manuels du système éducatif français.
            </p>
            <Link href="/programmes/francais" className="btn-primary mt-6 inline-flex">
              Découvrir le programme
            </Link>
          </div>
        </div>
      </section>

      {/* Valeurs / atouts pédagogiques */}
      <section className="bg-olive-50 py-16 sm:py-20">
        <div className="container-gso">
          <span className="section-label">Notre pédagogie</span>
          <h2 className="mt-2 font-display text-3xl font-semibold text-olive-900">
            Ce qui distingue nos élèves
          </h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {valeurs.map(({ titre, texte, Icon }) => (
              <div key={titre} className="rounded-2xl border border-olive-100 bg-white p-6 shadow-card">
                <Icon className="h-7 w-7 text-olive-600" />
                <h3 className="mt-3 font-display text-base font-semibold text-olive-900">{titre}</h3>
                <p className="mt-2 font-body text-sm text-olive-900/70">{texte}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Méthodes d'enseignement */}
      <section className="container-gso py-16 sm:py-20">
        <span className="section-label">Méthodes d'enseignement</span>
        <h2 className="mt-2 font-display text-3xl font-semibold text-olive-900">
          Une pédagogie active et un suivi constant
        </h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {methodesEnseignement.map((m) => (
            <div key={m.titre} className="rounded-2xl border border-olive-100 bg-white p-6 shadow-card">
              <h3 className="font-display text-base font-semibold text-olive-900">{m.titre}</h3>
              <p className="mt-2 font-body text-sm text-olive-900/70">{m.texte}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Atouts établissement + séquences événementielles */}
      <section className="bg-olive-900 py-16 text-ivory sm:py-20">
        <div className="container-gso grid gap-10 lg:grid-cols-2">
          <div>
            <span className="section-label text-gilt-400">Nos atouts</span>
            <h2 className="mt-2 font-display text-2xl font-semibold">Pourquoi choisir le GSO</h2>
            <ul className="mt-6 space-y-3 font-body text-sm text-ivory/85">
              {atoutsEtablissement.map((a) => (
                <li key={a} className="flex gap-3">
                  <ShieldCheck className="mt-0.5 h-4 w-4 flex-shrink-0 text-gilt-400" />
                  <span>{a}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <span className="section-label text-gilt-400">Vie scolaire</span>
            <h2 className="mt-2 flex items-center gap-2 font-display text-2xl font-semibold">
              <PartyPopper className="h-6 w-6 text-gilt-400" /> Nos séquences événementielles
            </h2>
            <ul className="mt-6 space-y-3 font-body text-sm text-ivory/85">
              {evenements.map((e) => (
                <li key={e} className="flex gap-3">
                  <span className="mt-0.5 text-gilt-400">•</span>
                  <span>{e}</span>
                </li>
              ))}
            </ul>
            <p className="mt-6 font-body text-sm text-ivory/70">
              {pourquoiInscrire[1]}
            </p>
          </div>
        </div>
      </section>

      <section className="container-gso py-16 text-center sm:py-20">
        <h2 className="font-display text-2xl font-semibold text-olive-900">
          Prêt à inscrire votre enfant ?
        </h2>
        <div className="mt-6 flex flex-wrap justify-center gap-4">
          <Link href="/inscription" className="btn-primary">Inscrire mon enfant</Link>
          <Link href="/tarifs" className="btn-secondary">Voir les tarifs</Link>
        </div>
      </section>
    </div>
  );
}
