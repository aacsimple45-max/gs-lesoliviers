import type { Metadata } from "next";
import Link from "next/link";
import PageHero from "@/components/PageHero";

export const metadata: Metadata = {
  title: "Programme Français",
  description:
    "Programme Français du Groupe Scolaire Les Oliviers : Crèche, TPS, PS, MS, GS et Primaire (CP au CM2), méthodologie et manuels du système éducatif français, à Brazzaville.",
};

const cycles = [
  {
    titre: "Crèche",
    niveaux: "9 mois – 2 ans",
    texte:
      "Un environnement chaleureux et sécurisé pour les tout-petits : éveil sensoriel, chants, jeux et premiers repères, dans le respect du rythme de chaque enfant.",
  },
  {
    titre: "Maternelle",
    niveaux: "TPS, PS, MS, GS",
    texte:
      "Découverte du monde, du langage, des couleurs et des formes, initiation au pré-calcul et à la lecture, préparation progressive à l'entrée au CP.",
  },
  {
    titre: "Primaire",
    niveaux: "CP à CM2",
    texte:
      "Programme et manuels du système éducatif français, apprentissage structuré de la lecture, de l'écriture et des mathématiques, ouverture à l'anglais et aux sciences.",
  },
];

export default function ProgrammeFrancaisPage() {
  return (
    <div>
      <PageHero
        image="/images/hero-banner.png"
        alt="Rentrée scolaire, programme français"
        eyebrow="Programme Français"
        title="De la crèche au CM2, la méthode française"
        subtitle="Un parcours de la petite enfance à la fin du primaire, avec les programmes et la pédagogie du système éducatif français."
        height="h-[45vh] min-h-[320px]"
      />

      <section className="container-gso py-16 sm:py-20">
        <div className="space-y-6">
          {cycles.map((c) => (
            <div key={c.titre} className="rounded-2xl border border-olive-100 bg-white p-6 shadow-card sm:p-8">
              <span className="section-label">{c.niveaux}</span>
              <h2 className="mt-1 font-display text-xl font-semibold text-olive-900">{c.titre}</h2>
              <p className="mt-2 max-w-3xl font-body text-sm text-olive-900/70">{c.texte}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-gso py-16 text-center sm:py-20">
        <h2 className="font-display text-2xl font-semibold text-olive-900">
          Fournitures et tarifs du Programme Français
        </h2>
        <div className="mt-6 flex flex-wrap justify-center gap-4">
          <Link href="/fournitures" className="btn-primary">Voir les fournitures</Link>
          <Link href="/tarifs" className="btn-secondary">Voir les tarifs</Link>
        </div>
      </section>
    </div>
  );
}
