import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import PageHero from "@/components/PageHero";

export const metadata: Metadata = {
  title: "Programme Congolais",
  description:
    "Programme Congolais du Groupe Scolaire Les Oliviers : préscolaire, primaire, collège, Lycée Général (séries A et S) et Lycée Technique (Secrétariat, Comptabilité, Marketing & Gestion, Économie), à Brazzaville.",
};

const cycles = [
  {
    titre: "Préscolaire",
    niveaux: "Crèche, P1, P2, P3",
    texte:
      "À la crèche, les enfants apprennent à chanter, à distinguer les objets et les couleurs, avec une initiation au pré-calcul. La maternelle (P1 à P3) prépare progressivement à l'entrée au primaire.",
  },
  {
    titre: "Primaire",
    niveaux: "CP1 à CM2",
    texte:
      "Apprentissage des fondamentaux (lecture, écriture, calcul), initiation à l'anglais dès le CP, informatique et Internet dès le CE1, préparation au Certificat d'Études Primaires Élémentaires (CEPE).",
  },
  {
    titre: "Collège",
    niveaux: "6e à 3e",
    texte:
      "Consolidation des acquis et diversification des matières (SVT, Physique-Chimie, Histoire-Géographie...), préparation au Brevet d'Études du Premier Cycle (BEPC).",
  },
  {
    titre: "Lycée Général",
    niveaux: "Seconde, Première, Terminale — Séries A et S",
    texte:
      "La série S regroupe désormais les anciennes séries C et D. Préparation au Baccalauréat, avec un accompagnement renforcé en classes d'examen.",
  },
  {
    titre: "Lycée Technique",
    niveaux: "Filières G1 (Secrétariat), G2 (Comptabilité), G3 (Marketing & Gestion Financière), BG (Économie)",
    texte:
      "Une formation qui allie théorie et compétences pratiques, véritable passerelle vers les études supérieures et l'insertion professionnelle.",
  },
];

export default function ProgrammeCongolaisPage() {
  return (
    <div>
      <PageHero
        image="/images/hero-banner.png"
        alt="Rentrée scolaire, programme congolais"
        eyebrow="Programme Congolais"
        title="De la crèche au Lycée Général et Technique"
        subtitle="Un parcours complet, conforme au système éducatif congolais, jusqu'au Baccalauréat général ou technique."
        height="h-[45vh] min-h-[320px]"
      />

      <section className="container-gso py-16 sm:py-20">
        <div className="space-y-6">
          {cycles.map((c) => (
            <div key={c.titre} className="rounded-2xl border border-olive-100 bg-white p-6 shadow-card sm:p-8">
              <span className="section-label">{c.niveaux}</span>
              <h2 className="mt-1 font-display text-xl font-semibold text-olive-900">{c.titre}</h2>
              <p className="mt-2 max-w-3xl font-body text-sm text-olive-900/70">{c.texte}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-olive-50 py-14">
        <div className="container-gso flex flex-col items-start gap-6 sm:flex-row sm:items-center">
          <Image
            src="/images/reglement-tenue.png"
            alt="Règlement de la tenue scolaire"
            width={160}
            height={200}
            className="rounded-xl border border-olive-100 object-cover"
          />
          <div>
            <h2 className="font-display text-lg font-semibold text-olive-900">Tenue scolaire</h2>
            <p className="mt-2 max-w-2xl font-body text-sm text-olive-900/70">
              Chaque cycle et chaque classe a sa couleur de tenue de sport (voir la fiche fournitures
              de la classe de votre enfant). Merci de vous référer au règlement affiché à l'école pour
              la tenue civile.
            </p>
          </div>
        </div>
      </section>

      <section className="container-gso py-16 text-center sm:py-20">
        <h2 className="font-display text-2xl font-semibold text-olive-900">
          Fournitures et tarifs du Programme Congolais
        </h2>
        <div className="mt-6 flex flex-wrap justify-center gap-4">
          <Link href="/fournitures" className="btn-primary">Voir les fournitures</Link>
          <Link href="/tarifs" className="btn-secondary">Voir les tarifs</Link>
        </div>
      </section>
    </div>
  );
}
