import type { Metadata } from "next";
import Image from "next/image";
import { supabaseServer } from "@/lib/supabase-server";

export const metadata: Metadata = {
  title: "Galerie",
  description: "Galerie photo du Groupe Scolaire Les Oliviers : évènements, activités, infrastructures.",
};

export const revalidate = 60;

export default async function GaleriePage() {
  const supabase = supabaseServer();
  const { data: photos } = await supabase
    .from("galerie")
    .select("*")
    .order("ordre")
    .order("cree_le", { ascending: false });

  const categories = Array.from(new Set((photos ?? []).map((p) => p.categorie)));

  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Vie scolaire</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">Galerie</h1>
      <p className="mt-4 max-w-2xl font-body text-olive-900/70">
        Évènements, activités, cérémonies, infrastructures et sorties pédagogiques au Groupe Scolaire
        Les Oliviers.
      </p>

      {(!photos || photos.length === 0) && (
        <p className="mt-8 max-w-xl font-body text-olive-900/70">
          Aucune photo pour le moment. Revenez bientôt pour découvrir la vie de l'école en images.
        </p>
      )}

      {categories.map((cat) => (
        <div key={cat} className="mt-12">
          <h2 className="font-display text-xl font-semibold text-mustard-600">{cat}</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {photos!
              .filter((p) => p.categorie === cat)
              .map((p) => (
                <div key={p.id} className="group relative aspect-square overflow-hidden rounded-2xl border border-olive-100 shadow-card">
                  <Image
                    src={p.image_url}
                    alt={p.titre ?? cat}
                    fill
                    className="object-cover transition duration-300 group-hover:scale-105"
                    unoptimized
                  />
                  {p.titre && (
                    <div className="absolute inset-x-0 bottom-0 bg-olive-950/70 px-3 py-2">
                      <p className="font-body text-xs text-ivory">{p.titre}</p>
                    </div>
                  )}
                </div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}
