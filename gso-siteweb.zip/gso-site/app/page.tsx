import Link from "next/link";
import PageHero from "@/components/PageHero";
import ClassroomSVG from "@/components/illustrations/ClassroomSVG";
import LibrarySVG from "@/components/illustrations/LibrarySVG";
import MultimediaSVG from "@/components/illustrations/MultimediaSVG";

const atouts = [
  { titre: "Enseignement de qualité", texte: "Enseignants recrutés sur titres, encadrés par des inspecteurs expérimentés." },
  { titre: "Encadrement rigoureux", texte: "Suivi personnalisé de chaque élève, devoirs et évaluations réguliers." },
  { titre: "Programme Congolais", texte: "De la crèche au Lycée Général et Technique." },
  { titre: "Programme Français", texte: "De la crèche au CM2, méthodologie française." },
  { titre: "Infrastructures modernes", texte: "Salles aérées, salle multimédia, bibliothèque, structures sanitaires adéquates." },
  { titre: "Activités extrascolaires", texte: "Théâtre, club de lecture, chorale, football, handball, olympiades." },
];

const stats = [
  { chiffre: "2", label: "Programmes (Congolais & Français)" },
  { chiffre: "10+", label: "Niveaux, de la crèche au lycée" },
  { chiffre: "3", label: "Filières au Lycée (Général, Technique, Commercial)" },
  { chiffre: "100%", label: "Exonération BEPC/CEPE = réinscription gratuite" },
];

const infrastructures = [
  { titre: "Salles de classe", texte: "Salles propres, aérées et adaptées à chaque cycle.", Illustration: ClassroomSVG },
  { titre: "Bibliothèque", texte: "Un espace dédié au livre, avec initiation à la technique bibliothécaire.", Illustration: LibrarySVG },
  { titre: "Salle multimédia", texte: "Équipée d'ordinateurs, avec accès Internet dès le CE1.", Illustration: MultimediaSVG },
];

export default function HomePage() {
  return (
    <div>
      <PageHero
        image="/images/facade-ecole.png"
        alt="Façade du Groupe Scolaire Les Oliviers, Batignolles, Brazzaville"
        eyebrow="Rentrée scolaire 2026 – 2027"
        title="Faire de nous votre choix, c'est choisir la réussite."
        subtitle="Groupe Scolaire Les Oliviers — école privée à Brazzaville, de la crèche au lycée, au programme congolais et au programme français."
      >
        <div className="mt-8 flex flex-wrap gap-4">
          <Link href="/inscription" className="btn-primary">Inscrire mon enfant</Link>
          <Link href="/programmes" className="btn-secondary">Découvrir nos programmes</Link>
        </div>
      </PageHero>

      {/* PRESENTATION */}
      <section className="container-gso py-16 sm:py-20">
        <span className="section-label">Qui sommes-nous</span>
        <h2 className="mt-2 font-display text-3xl font-semibold text-olive-900">
          Excellence, discipline et réussite scolaire
        </h2>
        <p className="mt-4 max-w-3xl font-body text-olive-900/80">
          Le Groupe Scolaire Les Oliviers accompagne les élèves de la crèche au lycée, au programme
          congolais comme au programme français. Notre mission : offrir un encadrement personnalisé,
          des infrastructures propres et sécurisées, et une direction tenue par des spécialistes de
          l'éducation, pour préparer chaque enfant à réussir.
        </p>
      </section>

      {/* ATOUTS */}
      <section className="bg-olive-50 py-16 sm:py-20">
        <div className="container-gso">
          <span className="section-label">Nos atouts</span>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {atouts.map((a) => (
              <div key={a.titre} className="rounded-2xl border border-olive-100 bg-white p-6 shadow-card">
                <h3 className="font-display text-lg font-semibold text-olive-900">{a.titre}</h3>
                <p className="mt-2 font-body text-sm text-olive-900/70">{a.texte}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INFRASTRUCTURES */}
      <section className="container-gso py-16 sm:py-20">
        <span className="section-label">Nos infrastructures</span>
        <h2 className="mt-2 font-display text-3xl font-semibold text-olive-900">
          Un cadre propice à l'apprentissage
        </h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-3">
          {infrastructures.map(({ titre, texte, Illustration }) => (
            <div key={titre} className="overflow-hidden rounded-2xl border border-olive-100 bg-white shadow-card">
              <Illustration className="h-44 w-full" />
              <div className="p-5">
                <h3 className="font-display text-lg font-semibold text-olive-900">{titre}</h3>
                <p className="mt-2 font-body text-sm text-olive-900/70">{texte}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* STATS */}
      <section className="container-gso py-16 sm:py-20">
        <div className="grid gap-6 sm:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <div className="font-display text-4xl font-semibold text-mustard-600">{s.chiffre}</div>
              <div className="mt-2 font-body text-sm text-olive-900/70">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA DOCUMENTS */}
      <section className="bg-olive-900 py-16 text-ivory sm:py-20">
        <div className="container-gso flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-semibold">Prospectus et fournitures scolaires</h2>
            <p className="mt-2 max-w-lg font-body text-ivory/70">
              Consultez et téléchargez les prospectus et les listes de fournitures pour chaque
              programme et chaque classe.
            </p>
          </div>
          <div className="flex flex-wrap gap-4">
            <Link href="/prospectus" className="btn-secondary">Voir les prospectus</Link>
            <Link
              href="/fournitures"
              className="inline-flex items-center justify-center rounded-full border border-ivory/30 px-6 py-3 font-body text-sm font-semibold text-ivory transition hover:bg-ivory/10"
            >
              Voir les fournitures
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
