import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { supabaseServer } from "@/lib/supabase-server";

export const revalidate = 60;

async function getArticle(id: string) {
  const supabase = supabaseServer();
  const { data } = await supabase
    .from("actualites")
    .select("*")
    .eq("id", id)
    .eq("statut", "publie")
    .single();
  return data;
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const article = await getArticle(params.id);
  if (!article) return { title: "Article introuvable" };

  return {
    title: article.titre,
    description: article.resume ?? article.titre,
    openGraph: {
      title: article.titre,
      description: article.resume ?? article.titre,
      images: article.image_url ? [article.image_url] : ["/images/facade-ecole.png"],
      type: "article",
    },
  };
}

export default async function ArticlePage({ params }: { params: { id: string } }) {
  const article = await getArticle(params.id);
  if (!article) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    headline: article.titre,
    image: article.image_url ? [article.image_url] : undefined,
    datePublished: article.publie_le ?? article.cree_le,
    author: article.auteur ? { "@type": "Person", name: article.auteur } : undefined,
    publisher: {
      "@type": "Organization",
      name: "Groupe Scolaire Les Oliviers",
      logo: { "@type": "ImageObject", url: "https://www.gsoliviers.com/images/logo.png" },
    },
  };

  return (
    <article className="container-gso py-14 sm:py-20">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <Link href="/actualites" className="font-body text-sm text-olive-700 hover:text-olive-900">
        ← Toutes les actualités
      </Link>

      {article.categorie && <p className="section-label mt-4">{article.categorie}</p>}
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">{article.titre}</h1>
      {article.sous_titre && (
        <p className="mt-2 font-body text-lg text-olive-900/70">{article.sous_titre}</p>
      )}
      <p className="mt-3 font-body text-xs text-olive-900/50">
        {article.auteur ? `${article.auteur} · ` : ""}
        {new Date(article.publie_le ?? article.cree_le).toLocaleDateString("fr-FR", {
          day: "numeric", month: "long", year: "numeric",
        })}
      </p>

      {article.image_url && (
        <div className="relative mt-8 h-72 w-full overflow-hidden rounded-2xl sm:h-96">
          <Image src={article.image_url} alt={article.titre} fill className="object-cover" unoptimized />
        </div>
      )}

      <div className="prose prose-olive mt-8 max-w-2xl font-body text-olive-900/85">
        {(article.contenu ?? article.resume ?? "").split("\n").map((p: string, i: number) => (
          p.trim() && <p key={i} className="mt-4">{p}</p>
        ))}
      </div>
    </article>
  );
}
