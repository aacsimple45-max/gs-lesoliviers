import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { supabaseServer } from "@/lib/supabase-server";

export const metadata: Metadata = {
  title: "Actualités",
  description: "Actualités et évènements du Groupe Scolaire Les Oliviers.",
};

export const revalidate = 60;

export default async function ActualitesPage() {
  const supabase = supabaseServer();
  const { data: articles } = await supabase
    .from("actualites")
    .select("*")
    .eq("statut", "publie")
    .order("publie_le", { ascending: false });

  return (
    <div className="container-gso py-14 sm:py-20">
      <span className="section-label">Vie scolaire</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-olive-900 sm:text-4xl">Actualités</h1>

      {(!articles || articles.length === 0) && (
        <p className="mt-8 max-w-xl font-body text-olive-900/70">
          Aucune actualité publiée pour le moment. Revenez bientôt pour suivre la vie de l'école.
        </p>
      )}

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {articles?.map((a) => (
          <Link
            key={a.id}
            href={`/actualites/${a.id}`}
            className="overflow-hidden rounded-2xl border border-olive-100 bg-white shadow-card transition hover:border-olive-300"
          >
            {a.image_url && (
              <div className="relative h-40 w-full">
                <Image src={a.image_url} alt={a.titre} fill className="object-cover" unoptimized />
              </div>
            )}
            <div className="p-5">
              {a.categorie && (
                <span className="section-label">{a.categorie}</span>
              )}
              <h2 className="mt-1 font-display text-lg font-semibold text-olive-900">{a.titre}</h2>
              {a.resume && <p className="mt-2 font-body text-sm text-olive-900/70">{a.resume}</p>}
              <p className="mt-3 font-body text-xs text-olive-900/50">
                {a.auteur ? `${a.auteur} · ` : ""}
                {a.publie_le ? new Date(a.publie_le).toLocaleDateString("fr-FR") : ""}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
